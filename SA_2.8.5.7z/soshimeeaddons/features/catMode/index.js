/// <reference types="../../../CTAutocomplete" />

import ReflectionHelper from "../../utils/reflection";

const EntityOcelot = Java.type("net.minecraft.entity.passive.EntityOcelot");

const renderManager = Client.getMinecraft().func_175598_ae();
const fakeEntity = new EntityOcelot(World.getWorld());

// const renderer = renderManager.func_78713_a(fakeEntity);

const renderTrigger = register("renderEntity", (entity, _, partialTicks, event) => {
	if (entity.getClassName() !== "EntityPlayerSP") return;
	copyProperties(entity.getEntity(), fakeEntity);
	renderManager.func_147937_a(fakeEntity, partialTicks);
	// renderer.func_76986_a(fakeEntity, position.getX(), position.getY(), position.getZ(), entity.getYaw(), 1);
	cancel(event);
}).unregister();

function copyProperties(from, to) {
	const fromHelper = new ReflectionHelper(from);
	const toHelper = new ReflectionHelper(to);
	to.func_70080_a(from.field_70165_t, from.field_70163_u, from.field_70161_v, from.field_70177_z, from.field_70125_A);
	// x, y, z, yaw, pitch
	// to.field_70165_t = from.field_70165_t;
	// to.field_70163_u = from.field_70163_u;
	// to.field_70161_v = from.field_70161_v;
	// to.field_70177_z = from.field_70177_z;
	// to.field_70125_A = from.field_70125_A;
	// // (prev) x, y, z, yaw, pitch
	// to.field_70169_q = from.field_70169_q;
	// to.field_70167_r = from.field_70167_r;
	// to.field_70166_s = from.field_70166_s;
	// to.field_70126_B = from.field_70126_B;
	// to.field_70127_C = from.field_70127_C;
	// // (last) x, y, z
	// to.field_70142_S = from.field_70142_S;
	// to.field_70137_T = from.field_70137_T;
	// to.field_70136_U = from.field_70136_U;
	// misc
	to.func_70034_d(from.func_70079_am());
	to.field_70721_aZ = from.field_70721_aZ;
	to.field_70754_ba = from.field_70754_ba;
	to.field_70732_aI = from.field_70732_aI;
	to.field_70733_aJ = from.field_70733_aJ;
	to.field_82175_bq = from.field_82175_bq;
	to.func_181013_g(from.field_70761_aq);
	to.field_70737_aN = from.field_70737_aN;
	toHelper.setField("field_70151_c", fromHelper.getField("field_70151_c"));
	// to.field_70151_c = from.field_70151_c;
	to.field_70725_aQ = from.field_70725_aQ;
	to.func_85034_r(from.func_85035_bI());
	to.func_70031_b(from.func_70051_ag());
	to.func_82142_c(from.func_82150_aj());
	to.func_70095_a(from.func_70093_af());
	// to.field_70727_aS = from.field_70727_aS;
	to.field_70760_ar = from.field_70760_ar;
	to.field_70722_aY = from.field_70722_aY;
	to.field_70758_at = from.field_70758_at;
}

export function enable() {
	renderTrigger.register();
}

export function disable() {
	renderTrigger.unregister();
}

export default { enable, disable };
